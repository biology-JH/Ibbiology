# Plan — IB Biology B3.1 Gas Exchange SL and HL website

## Request (verbatim intent)

Build a concise website explaining **IB Biology B3.1 Gas Exchange SL and HL** that:

- states the **syllabus points** explicitly and labels level (SL & HL vs HL ONLY);
- uses **the pictures from the attached documents** (not generated/stock imagery), embedded in their matching lesson text with **annotations** rather than a separate front-page gallery;
- gives full treatment to the **Additional Higher Level** points:
  - **B3.1.11** Adaptations of foetal and adult haemoglobin for the transport of oxygen — cooperative binding of oxygen to haem groups, allosteric binding of carbon dioxide;
  - **B3.1.12** Bohr shift — increased CO₂ causes increased dissociation of O₂, benefits for actively respiring tissues;
  - **B3.1.13** Oxygen dissociation curves as a representation of haemoglobin affinity at different oxygen concentrations; explain the S-shaped form via cooperative binding;
- answers the two **linking questions**: access to materials for all cells in multicellular organisms, and the relationship between gas exchange and cell metabolic processes.

Confirmed features: all B3.1.1–B3.1.13 labelled and navigable; focused HL treatment; concise SL foundations with a clear principles table; linking-question answers; all 11 source figures from the two supplied documents; challenging MCQs after each lesson section.

## Implementation approach

- **Static, client-rendered single-page study site** built with **Vite + React 19 + TypeScript + Tailwind CSS v4**. No server or database is required (config keeps `features.server=false`, `features.database=false`); all content is authored data, so the whole site ships as static output (`dist/`).
- Content lives in **typed data modules** under `src/data/` so syllabus statements, sections, annotation legends and quiz items stay reviewable and consistent; components render that data.
- **Lesson sequence** — Add a short retrieval starter and What/Why/How objectives near the beginning; finish the teaching sections with a concise plenary exit ticket and revealable model response.
- **Figures come only from the user's documents.** Keep the seven existing study-guide images and embed the four diagrams from `Essential-Biological-Diagrams-Physiology-&-Anatomy.docx` in their matching lesson text and annotation keys; do not add a separate front-page gallery or figure-count callout. Preserve original PNG quality and proportions.
- **Annotation strategy:** the document figures already carry printed labels, so each is presented as a numbered *plate* whose annotation legend explains **structure → function** for every label, plus **hotspot markers** (percentage-positioned overlays with hover/tap tooltips) where they add value — required for the unlabelled stomatal micrograph and used for the alveolus EM.
- **Instruction and practice:** replace hand-drawn science diagrams with the supplied originals. Use concise text, tables and annotation keys; add two challenging MCQs after each of the ten lesson sections, with immediate feedback and explanations.
- **Level-aware navigation:** a persistent rail indexes every syllabus statement; clear icon-led links jump to the SL and HL lesson starts; an "HL focus" toggle dims shared SL material when revising AHL content.
- **Serving:** `vite dev` on the project runtime port 3000 bound to `0.0.0.0`; production output `dist/` declared through the `build` config. No login, no cookies, no X-Frame-Options/`frame-ancestors` restrictions so the Cloud Preview iframe embeds correctly. All browser-facing URLs are relative.
- **Metadata:** route-specific title/description/OG/Twitter tags in `index.html` with a `<noscript>` content fallback; absolute canonical/`og:url` values are omitted rather than guessed for an unconfigured public origin. `public/manus-routes.json` declares the single route.
- **Polish:** `app.config.ts` carries a durable HTTPS `logoUrl` before checkpointing; checkpoint pushed to the canonical Manus repository on `main`.

## Project structure

```
gasxchange/
├─ index.html                 # document head: title, description, OG/Twitter, fonts, noscript content
├─ app.config.ts              # platform branding (logoUrl)
├─ package.json / lockfile    # pinned toolchain and scripts
├─ vite.config.ts             # React + Tailwind v4 plugin, dev server bound to 0.0.0.0:3000
├─ public/
│  ├─ manus-routes.json       # route manifest for the dev server
│  └─ images/*.{png,jpg}      # 7 original study-guide images
└─ src/
   ├─ main.tsx, App.tsx       # entry, page composition and level-filter state
   ├─ styles.css              # Tailwind theme tokens + bespoke plate/annotation styling
   ├─ data/
   │  ├─ syllabus.ts          # B3.1.1–B3.1.13 statements, level tags, anchors
   │  ├─ figures.ts           # 11 source-image plates, annotations and hotspots
   │  └─ sessionChecks.ts     # challenging MCQs grouped by lesson section
   ├─ components/
   │  ├─ Hero, LearningSequence, SiteHeader         # introduction, starter/objectives/plenary and navigation
   │  ├─ SyllabusRail, SyllabusMap                   # syllabus navigation and coverage
   │  ├─ ui.tsx, SessionCheck # section shell, source-image plates and self-checks
   │  ├─ CheckUnderstanding, Glossary, SiteFooter    # cumulative quiz, terms and footer
   └─ sections/               # foundations, plants, HL lessons and synthesis
```

## Design

**Design movement** — *Scientific monograph / museum specimen plate*: the look of a well-set modern biology textbook plate crossed with a research paper's figure pages — paper, ink, ruled captions, numbered plates.

**Core principles** — (1) The figure is the argument: every diagram is a numbered plate with ruled annotation, never decoration. (2) Traceability: every block carries its syllabus code and a level badge, so revision is auditable. (3) Dense but calm: measured two-column prose, wide figure breaks, generous vertical rhythm. (4) Scientific honesty: correct subscripts/superscripts, units and partial pressures throughout.

**Color philosophy** — Warm paper `#F6F3EC` and ink `#182029` keep long reading comfortable, evoking print revision guides. Deep "specimen blue" `#0F4258` anchors science and structure. Haemoglobin crimson `#B3372B` marks oxygen-rich, arterial ideas; petrel teal-green `#2F6B5F` marks oxygen-poor/plant ideas. Amber `#C77E1B` is reserved exclusively for the **HL ONLY** badge so AHL-only material is instantly skimmable. Colour always carries meaning, never decoration.

**Layout paradigm** — *Plate and note*: an asymmetric reading layout with a slim sticky left rail carrying plate/section numbers and the syllabus index, a main measure of ~68 characters, and figures that break out to the outer margin at full plate width. Sections are separated by rules and numbered like printed figures, not boxed into cards.

**Signature elements** — (1) Numbered plates: `PLATE 03 — Structure of the alveolus`, ruled, with source line and annotation legend. (2) Syllabus chips: mono uppercase pills such as `B3.1.11 · HL ONLY`. (3) Circled annotation markers over figures, keyed to a ruled legend beneath.

**Interaction philosophy** — Reading first, practice second: a retrieval starter and What/Why/How objectives frame the course; original figures stay intact with concise annotations; a plenary exit ticket closes instruction; each lesson ends with two MCQs and immediate feedback.

**Animation** — Restrained: 400–600 ms ease-out reveals with 8 px rise and no bounce; hotspot markers respond only on hover or tap; quiz feedback appears immediately. `prefers-reduced-motion` disables motion.

**Typography system** — Display/headings: **Fraunces** (variable serif, soft-wonky axis) for plate titles and section headings; body: **Source Serif 4** at 18–19 px with 1.65 line-height for a printable monograph feel; UI/labels/annotations: **Inter**; syllabus codes, units and data: **IBM Plex Mono**. Hierarchy via size and colour, not weight inflation; headings are short (≤ 80 chars).

**Brand essence** — A print-grade, figure-driven B3.1 revision companion for IB Biology candidates who must know exactly which statements are Additional Higher Level — *rigorous, legible, unhurried*.

**Brand voice** — Precise, exam-literate, quietly confident. Example headline: "Two oxygen curves, one placenta." Example microcopy: "Step the haem: watch affinity rise."

**Wordmark & logo** — Wordmark "GASTEMPERA" set in Fraunces with the final `A` cut by a ruled baseline; mark is a mono-labelled sigmoid curve inside a circle, used as the favicon.

**Signature brand colour** — **Specimen Teal `#0E5A63`**: the ownable hue of the wordmark, rail and interactive controls, used nowhere else.

## Material constraints

- The 7 study-guide plates and all 4 new physiology/anatomy diagrams must remain sourced from the two attached DOCX files (`word/media/*`); do not generate substitutes for the four matched diagrams.
- No server, database, login or external API; no secrets.
- HL/SL labelling must match IB language exactly (`[SL & HL]`, `[HL ONLY]`).
