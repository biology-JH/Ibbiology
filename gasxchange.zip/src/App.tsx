import { useState } from 'react'
import { SiteHeader } from './components/SiteHeader'
import { SiteFooter } from './components/SiteFooter'
import { SyllabusRail } from './components/SyllabusRail'
import { SyllabusMap } from './components/SyllabusMap'
import { Hero, HowToUse } from './components/Hero'
import { CourseStart, Plenary } from './components/LessonSequence'
import { CheckUnderstanding } from './components/CheckUnderstanding'
import { Glossary } from './components/Glossary'
import { GradientsSection, LungsSection, PrinciplesSection, VentilationSection } from './sections/Foundations'
import { LeafSection, StomataSection } from './sections/Plants'
import { HaemoglobinSection } from './sections/HaemoglobinSection'
import { BohrShiftSection } from './sections/BohrShiftSection'
import { CurvesSection } from './sections/CurvesSection'
import { SynthesisSection } from './sections/SynthesisSection'

export default function App() {
  const [hlFocus, setHlFocus] = useState(false)

  return (
    <div id="top" className={hlFocus ? 'hl-focus' : undefined}>
      <a
        href="#syllabus"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-white focus:px-3 focus:py-2 focus:font-ui focus:text-sm"
      >
        Skip to the syllabus coverage map
      </a>

      <SiteHeader hlFocus={hlFocus} onToggleHlFocus={() => setHlFocus((value) => !value)} />

      <main>
        <Hero />
        <HowToUse />
        <CourseStart />

        <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
          <div className="grid gap-x-12 lg:grid-cols-[15rem_minmax(0,1fr)]">
            <SyllabusRail />

            <div className="min-w-0">
              <SyllabusMap />
              <PrinciplesSection />
              <GradientsSection />
              <LungsSection />
              <VentilationSection />
              <LeafSection />
              <StomataSection />
              <HaemoglobinSection />
              <BohrShiftSection />
              <CurvesSection />
              <SynthesisSection />
              <Plenary />
              <CheckUnderstanding />
              <Glossary />
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
