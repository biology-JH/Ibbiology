import { useEffect, useRef, useState, type RefObject } from 'react'

/** Reports whether the referenced element has entered the viewport at least once. */
export function useInView<T extends Element>(rootMargin = '0px 0px -10% 0px'): [RefObject<T | null>, boolean] {
  const ref = useRef<T | null>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const element = ref.current

    if (!element) {
      return
    }

    if (typeof IntersectionObserver === 'undefined') {
      setInView(true)
      return
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setInView(true)
            observer.disconnect()
          }
        })
      },
      { rootMargin, threshold: 0.05 },
    )

    observer.observe(element)

    return () => observer.disconnect()
  }, [rootMargin])

  return [ref, inView]
}