import { syllabus, levelClass } from '../data/syllabus'
import { Reveal } from './Reveal'

/**
 * The syllabus coverage map: every statement in B3.1, tagged with its level and
 * linked to the section that explains it.
 */
export function SyllabusMap() {
  const hlCount = syllabus.filter((statement) => statement.level === 'HL ONLY').length

  return (
    <section id="syllabus" className="scroll-mt-28 py-14" aria-labelledby="syllabus-heading">
      <header className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-10">
        <div>
          <span className="eyebrow">Syllabus coverage map</span>
          <h2 id="syllabus-heading" className="mt-2 text-[1.85rem] sm:text-[2.15rem]">
            B3.1 syllabus map
          </h2>
        </div>
        <p className="measure text-[0.98rem] text-ink-soft lg:pt-9">
          <span className="chip chip--sl chip--sm">SL &amp; HL</span> marks shared content.{' '}
          <span className="chip chip--hl chip--sm">HL ONLY</span> marks the {hlCount} Additional Higher Level points.
        </p>
      </header>

      <ol className="mt-8 grid list-none gap-x-8 gap-y-0 p-0 md:grid-cols-2 xl:grid-cols-3">
        {syllabus.map((statement, index) => (
          <li key={statement.code} data-level={levelClass(statement.level)} className="border-t border-ink/15">
            <Reveal delay={Math.min(index * 30, 240)}>
              <a href={`#${statement.sectionId}`} className="group block py-4 no-underline">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[0.76rem] tracking-[0.08em] text-teal">{statement.code}</span>
                  <span className={`chip chip--sm ${statement.level === 'HL ONLY' ? 'chip--hl' : 'chip--sl'}`}>
                    {statement.level === 'HL ONLY' ? 'HL ONLY' : 'SL & HL'}
                  </span>
                </div>
                <p className="mt-2 mb-0 text-[0.94rem] leading-[1.6] text-ink-soft group-hover:text-ink">
                  {statement.text}
                </p>
                <span className="mt-2 inline-block font-ui text-[0.74rem] tracking-wide text-ink-faint group-hover:text-teal">
                  Go to the explanation →
                </span>
              </a>
            </Reveal>
          </li>
        ))}
      </ol>
    </section>
  )
}
