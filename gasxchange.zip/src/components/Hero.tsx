import { Reveal } from './Reveal'

const facts = [
  { k: 'Syllabus', v: 'B3.1.1–B3.1.13' },
  { k: 'Coverage', v: 'SL & HL · three HL-only points' },
  { k: 'Practice', v: 'Two challenging MCQs after each section' },
  { k: 'Core idea', v: 'Exchange · transport · metabolism' },
]

function LevelJump({ href, level, label, primary = false }: { href: string; level: 'SL' | 'HL'; label: string; primary?: boolean }) {
  return (
    <a href={href} className={`btn level-jump !no-underline ${primary ? 'btn--active' : 'btn--ghost'}`}>
      <span className={`level-jump__mark level-jump__mark--${level.toLowerCase()}`} aria-hidden="true">
        {level}
      </span>
      <span>{label}</span>
      <svg viewBox="0 0 16 16" aria-hidden="true" className="level-jump__arrow">
        <path d="M8 2.5v10m-4-4 4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </a>
  )
}

export function Hero() {
  return (
    <section className="relative overflow-hidden pb-12 pt-14 sm:pt-20" aria-labelledby="hero-heading">
      <div className="mx-auto grid max-w-[1180px] gap-12 px-5 sm:px-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,26rem)] lg:items-end">
        <div>
          <Reveal>
            <p className="eyebrow m-0">IB Biology · Theme B · Topic B3.1</p>
            <h1 id="hero-heading" className="mt-4 max-w-[22ch] text-[2.5rem] leading-[1.05] sm:text-[3.4rem]">
              IB Biology B3.1 Gas Exchange SL and HL
            </h1>
            <p className="measure mt-6 text-[1.1rem] text-ink-soft">
              Concise explanations mapped to the B3.1 syllabus.
            </p>
          </Reveal>

          <Reveal delay={120}>
            <nav className="mt-8 flex flex-wrap items-center gap-3" aria-label="Jump to level">
              <LevelJump href="#principles" level="SL" label="Go to SL" />
              <LevelJump href="#haemoglobin" level="HL" label="Go to HL" primary />
              <a href="#syllabus" className="btn btn--ghost !no-underline">Syllabus map</a>
            </nav>
          </Reveal>

          <Reveal delay={200}>
            <dl className="mt-10 grid gap-x-8 gap-y-5 sm:grid-cols-2">
              {facts.map((fact) => (
                <div key={fact.k} className="border-t border-ink/20 pt-3">
                  <dt className="font-ui text-[0.72rem] uppercase tracking-[0.14em] text-teal">{fact.k}</dt>
                  <dd className="mt-1 mb-0 text-[0.95rem] text-ink-soft">{fact.v}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        <Reveal delay={80}>
          <aside className="rounded-[3px] border border-ink/15 bg-white/75 p-6" aria-label="Course map">
            <p className="eyebrow m-0">Course map</p>
            <ol className="mt-4 mb-0 grid list-none gap-4 p-0">
              <li className="course-map__item">
                <span className="course-map__number">01–06</span>
                <span><strong>SL &amp; HL core</strong><br />Principles · lungs · plants</span>
              </li>
              <li className="course-map__item">
                <span className="course-map__number course-map__number--hl">07–09</span>
                <span><strong>Additional Higher Level</strong><br />Haemoglobin · Bohr shift · O₂ curves</span>
              </li>
              <li className="course-map__item">
                <span className="course-map__number">10</span>
                <span><strong>Linking questions</strong><br />Exchange · transport · metabolism</span>
              </li>
            </ol>
          </aside>
        </Reveal>
      </div>
    </section>
  )
}

export function HowToUse() {
  const steps = [
    { n: '01', title: 'Find', text: 'Choose a syllabus point.' },
    { n: '02', title: 'Study', text: 'Use the original figure and short key.' },
    { n: '03', title: 'Practise', text: 'Try two MCQs at the end of the section.' },
  ]

  return (
    <section className="mx-auto max-w-[1180px] px-5 sm:px-8" aria-label="How to use this guide">
      <div className="section-open grid gap-8 pt-8 pb-2 md:grid-cols-3">
        {steps.map((step) => (
          <Reveal key={step.n}>
            <div className="flex items-baseline gap-3">
              <span className="section-number">{step.n}</span>
              <h2 className="text-[1.15rem] text-ink">{step.title}</h2>
            </div>
            <p className="mt-2 mb-0 text-[0.95rem] text-ink-soft">{step.text}</p>
          </Reveal>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 border-y border-ink/12 py-3 font-mono text-[0.72rem] text-ink-faint">
        <span>Notation:</span>
        <span>O₂ · CO₂ · H₂CO₃ · H₂O</span>
        <span>H⁺ · HCO₃⁻ · Fe²⁺</span>
        <span>pO₂ · pCO₂</span>
        <span>SA:V</span>
        <span>πr²</span>
      </div>
    </section>
  )
}
