const objectives = [
  {
    label: 'What',
    text: 'Describe exchange surfaces, ventilation and oxygen transport, including B3.1.11–13.',
  },
  {
    label: 'Why',
    text: 'Link gas exchange to the oxygen and carbon-dioxide demands of cell metabolism.',
  },
  {
    label: 'How',
    text: 'Use diagrams, gradients, data and correct notation to explain mechanisms.',
  },
]

export function CourseStart() {
  return (
    <section className="mx-auto max-w-[1180px] px-5 sm:px-8" aria-label="Starter and learning objectives">
      <div className="grid gap-8 border-y border-ink/15 py-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:gap-10">
        <article id="starter" className="rounded-[3px] border border-ink/15 bg-white/70 p-5 scroll-mt-28">
          <p className="eyebrow m-0">Starter · 2 min</p>
          <h2 id="starter-heading" className="mt-2 text-[1.35rem] text-ink">Think about scale</h2>
          <p className="mt-3 mb-0 text-[0.98rem] text-ink-soft">
            As a multicellular organism grows, why can’t diffusion alone supply every cell?
          </p>
          <details className="mt-4 border-t border-ink/15 pt-3">
            <summary className="cursor-pointer font-ui text-[0.82rem] font-semibold text-teal underline underline-offset-4">
              Reveal a model answer
            </summary>
            <p className="mt-3 mb-0 text-[0.9rem] text-ink-soft">
              Surface area-to-volume ratio falls and diffusion paths lengthen. Specialised exchange surfaces and transport are needed to meet cell demand.
            </p>
          </details>
        </article>

        <div id="learning-objectives" className="scroll-mt-28" aria-labelledby="objectives-heading">
          <p className="eyebrow m-0">Learning objectives</p>
          <h2 id="objectives-heading" className="mt-2 text-[1.55rem] text-ink">By the end, you can…</h2>
          <dl className="mt-5 grid gap-x-6 gap-y-5 sm:grid-cols-3">
            {objectives.map((objective) => (
              <div key={objective.label} className="border-t border-ink/15 pt-3">
                <dt className="font-ui text-[0.72rem] uppercase tracking-[0.14em] text-teal">{objective.label}</dt>
                <dd className="mt-2 mb-0 text-[0.9rem] leading-relaxed text-ink-soft">{objective.text}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}

export function Plenary() {
  const prompts = [
    'Name one adaptation that maintains a steep diffusion gradient.',
    'Trace O₂ from the external medium to a respiring cell.',
    'At active tissue, explain how rising CO₂ changes haemoglobin’s O₂ release (HL).',
  ]

  return (
    <section id="plenary" className="section-open scroll-mt-28 pt-7 pb-12" aria-labelledby="plenary-heading">
      <header className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-10">
        <div>
          <span className="eyebrow">Plenary · exit ticket</span>
          <h2 id="plenary-heading" className="mt-2 text-[1.85rem] text-ink sm:text-[2.15rem]">
            Connect exchange to cell demand
          </h2>
        </div>
        <p className="measure text-[0.98rem] text-ink-soft lg:pt-9">
          Answer from memory, then reveal a model response.
        </p>
      </header>

      <ol className="mt-6 grid list-none gap-4 p-0 md:grid-cols-3">
        {prompts.map((prompt, index) => (
          <li key={prompt} className="border-t border-ink/15 pt-3">
            <span className="section-number">0{index + 1}</span>
            <p className="mt-2 mb-0 text-[0.94rem] text-ink-soft">{prompt}</p>
          </li>
        ))}
      </ol>

      <details className="mt-6 border-t border-ink/15 pt-3">
        <summary className="cursor-pointer font-ui text-[0.82rem] font-semibold text-teal underline underline-offset-4">
          Reveal a model response
        </summary>
        <p className="mt-3 mb-0 max-w-[72ch] text-[0.95rem] leading-relaxed text-ink-soft">
          Ventilation and blood flow maintain gradients; O₂ diffuses across a thin, large surface and is carried to respiring cells. In active tissue, CO₂ and H⁺ lower haemoglobin’s O₂ affinity, so more O₂ dissociates (the Bohr shift).
        </p>
      </details>
    </section>
  )
}
