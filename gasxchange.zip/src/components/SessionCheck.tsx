import { useState } from 'react'
import { sessionChecks } from '../data/sessionChecks'

const LETTERS = ['A', 'B', 'C', 'D']

export function SessionCheck({ sessionId }: { sessionId: string }) {
  const questions = sessionChecks[sessionId]
  const [answers, setAnswers] = useState<Record<string, number>>({})

  if (!questions?.length) return null

  const answered = questions.filter((question) => answers[question.id] !== undefined).length

  return (
    <aside className="session-check not-prose" aria-label="Check your understanding">
      <details>
        <summary className="session-check__summary">
          <span>
            <span className="eyebrow block">Session check</span>
            <span className="session-check__title">2 challenging multiple-choice questions</span>
          </span>
          <span className="session-check__progress" aria-live="polite">
            {answered}/{questions.length} answered
          </span>
        </summary>

        <ol className="session-check__list">
          {questions.map((question, index) => {
            const selected = answers[question.id]
            const hasAnswered = selected !== undefined

            return (
              <li key={question.id} className="session-check__question">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[0.7rem] text-ink-faint">Q{index + 1}</span>
                  <span className="chip chip--sm">{question.code}</span>
                </div>
                <p className="mt-2 mb-0 text-[0.98rem] text-ink">{question.prompt}</p>

                <div className="mt-3 flex flex-col gap-2">
                  {question.options.map((option, optionIndex) => {
                    const isSelected = selected === optionIndex
                    const isCorrect = optionIndex === question.correctIndex
                    const state = !hasAnswered ? undefined : isSelected ? (isCorrect ? 'correct' : 'wrong') : undefined

                    return (
                      <button
                        key={option}
                        type="button"
                        className="quiz-option"
                        data-state={state}
                        aria-pressed={isSelected}
                        onClick={() => setAnswers((current) => ({ ...current, [question.id]: optionIndex }))}
                      >
                        <span className="quiz-mark" aria-hidden="true">
                          {hasAnswered && isCorrect ? '✓' : hasAnswered && isSelected ? '×' : LETTERS[optionIndex]}
                        </span>
                        <span>{option}</span>
                      </button>
                    )
                  })}
                </div>

                {hasAnswered ? (
                  <div className="callout mt-3" role="status" aria-live="polite">
                    <p className="eyebrow m-0">{selected === question.correctIndex ? 'Correct' : 'Review'}</p>
                    <p className="mt-1 mb-0 text-[0.9rem] text-ink-soft">{question.explanation}</p>
                  </div>
                ) : null}
              </li>
            )
          })}
        </ol>
      </details>
    </aside>
  )
}
