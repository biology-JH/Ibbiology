import { useEffect, useState } from 'react'
import { sectionOrder, syllabus } from '../data/syllabus'

/**
 * Sticky index of every syllabus statement. The active entry tracks the section
 * currently occupying the upper half of the viewport.
 */
export function SyllabusRail() {
  const [activeId, setActiveId] = useState<string>(sectionOrder[0]?.id ?? '')

  useEffect(() => {
    const sections = sectionOrder
      .map((section) => document.getElementById(section.id))
      .filter((element): element is HTMLElement => Boolean(element))

    if (sections.length === 0 || typeof IntersectionObserver === 'undefined') {
      return
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)

        if (visible[0]) {
          setActiveId(visible[0].target.id)
        }
      },
      { rootMargin: '-15% 0px -55% 0px', threshold: 0 },
    )

    sections.forEach((section) => observer.observe(section))

    return () => observer.disconnect()
  }, [])

  return (
    <aside aria-label="Syllabus index" className="no-print hidden lg:block">
      <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto pr-1">
        <p className="eyebrow mb-3">Syllabus index</p>
        <nav>
          <ul className="list-none m-0 p-0">
            {syllabus.map((statement) => (
              <li key={statement.code} className="mb-0.5">
                <a
                  className="rail-link"
                  href={`#${statement.sectionId}`}
                  aria-current={activeId === statement.sectionId ? 'true' : 'false'}
                >
                  <span className="rail-link__code">
                    {statement.code}
                    {statement.level === 'HL ONLY' ? ' · HL' : ''}
                  </span>
                  {statement.railLabel}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="mt-6 border-t border-ink/12 pt-4">
          <p className="eyebrow mb-2">Sections</p>
          <ul className="list-none m-0 p-0">
            {sectionOrder.map((section) => (
              <li key={section.id} className="mb-0.5">
                <a
                  className="rail-link"
                  href={`#${section.id}`}
                  aria-current={activeId === section.id ? 'true' : 'false'}
                >
                  <span className="rail-link__code">§ {section.number}</span>
                  {section.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </aside>
  )
}