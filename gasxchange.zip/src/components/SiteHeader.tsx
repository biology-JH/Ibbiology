import { useEffect, useState } from 'react'
import { sectionOrder } from '../data/syllabus'

interface SiteHeaderProps {
  hlFocus: boolean
  onToggleHlFocus: () => void
}

export function SiteHeader({ hlFocus, onToggleHlFocus }: SiteHeaderProps) {
  const [progress, setProgress] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const update = () => {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight
      const ratio = scrollable > 0 ? window.scrollY / scrollable : 0
      setProgress(Math.min(1, Math.max(0, ratio)))
    }

    update()
    window.addEventListener('scroll', update, { passive: true })
    window.addEventListener('resize', update)

    return () => {
      window.removeEventListener('scroll', update)
      window.removeEventListener('resize', update)
    }
  }, [])

  return (
    <header className="sticky top-0 z-40 no-print">
      <div className="border-b border-ink/12 bg-paper/92 backdrop-blur-sm">
        <div className="relative mx-auto flex max-w-[1180px] items-center gap-6 px-5 py-3 sm:px-8">
          <a href="#top" className="flex items-baseline gap-2 no-underline text-ink">
            <span className="wordmark text-[1.05rem] text-teal">GASTEMPERA</span>
            <span className="hidden font-mono text-[0.62rem] tracking-[0.18em] text-ink-faint sm:inline">
              B3.1 · GAS EXCHANGE
            </span>
          </a>

          <nav aria-label="Sections" className="ml-auto hidden xl:block">
            <ul className="flex items-center gap-4 list-none m-0 p-0">
              <li>
                <a href="#principles" className="level-nav-link" aria-label="Go to SL core lessons" title="Go to SL core lessons">
                  <span className="level-nav-mark" aria-hidden="true">SL</span>
                  <span>01</span>
                </a>
              </li>
              {sectionOrder.slice(6).map((section) => (
                <li key={section.id}>
                  <a
                    href={`#${section.id}`}
                    className={`font-ui text-[0.78rem] no-underline hover:text-teal ${
                      section.level === 'HL ONLY' ? 'text-ink' : 'text-ink-faint'
                    }`}
                  >
                    {section.level === 'HL ONLY' ? `HL ${section.number}` : `§${section.number}`}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <label className="toggle ml-auto xl:ml-0" title="Dim the SL & HL material so the Additional Higher Level sections stand out">
            <input type="checkbox" checked={hlFocus} onChange={onToggleHlFocus} className="accent-teal" />
            <span>HL focus</span>
          </label>

          <button
            type="button"
            className="btn btn--ghost xl:hidden"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? 'Close' : 'Index'}
          </button>

          <span className="scroll-progress" style={{ width: `${progress * 100}%` }} aria-hidden="true" />
        </div>

          {menuOpen ? (
            <nav aria-label="Sections" className="border-t border-ink/10 bg-paper-deep/95 xl:hidden">
              <ul className="mx-auto grid max-w-[1180px] gap-1 px-5 py-4 list-none sm:px-8">
                {sectionOrder.map((section) => (
                <li key={section.id}>
                  <a
                    href={`#${section.id}`}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-baseline gap-3 py-1.5 no-underline text-ink-soft hover:text-teal"
                  >
                    <span className="font-mono text-[0.68rem] text-ink-faint">§{section.number}</span>
                    <span className="font-ui text-[0.85rem]">{section.title}</span>
                    {section.level === 'HL ONLY' ? <span className="chip chip--hl chip--sm">HL</span> : null}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        ) : null}
      </div>
    </header>
  )
}
