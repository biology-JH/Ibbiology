import { useState, type ReactNode } from 'react'
import type { Level } from '../data/syllabus'
import { levelClass } from '../data/syllabus'
import type { PlateData } from '../data/figures'
import { Reveal } from './Reveal'
import { SessionCheck } from './SessionCheck'

export function LevelBadge({ level }: { level: Level }) {
  const isHl = level === 'HL ONLY'

  return (
    <span className={`chip ${isHl ? 'chip--hl' : 'chip--sl'}`}>
      {isHl ? 'HL ONLY · Additional Higher Level' : 'SL & HL'}
    </span>
  )
}

export function SyllabusChips({ codes }: { codes: string[] }) {
  return (
    <ul className="flex flex-wrap items-center gap-2 list-none p-0 m-0">
      {codes.map((code) => (
        <li key={code}>
          <span className="chip chip--sm">{code}</span>
        </li>
      ))}
    </ul>
  )
}

interface SectionProps {
  id: string
  number: string
  title: string
  level: Level
  codes: string[]
  /** One-sentence orientation for the section. */
  lede?: string
  children: ReactNode
}

export function Section({ id, number, title, level, codes, lede, children }: SectionProps) {
  return (
    <section id={id} data-level={levelClass(level)} className="section-open scroll-mt-28 pt-7 pb-16">
      <header className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-10">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="section-number">§ {number}</span>
            <LevelBadge level={level} />
          </div>
          <h2 className="mt-3 text-[1.85rem] sm:text-[2.15rem] text-ink">{title}</h2>
        </div>
        <div className="lg:pt-8">
          <SyllabusChips codes={codes} />
          {lede ? <p className="mt-3 text-[0.95rem] text-ink-soft measure">{lede}</p> : null}
        </div>
      </header>
      <div className="mt-8">{children}</div>
      <SessionCheck sessionId={id} />
    </section>
  )
}

interface CalloutProps {
  kind?: 'default' | 'hl' | 'exam'
  label: string
  children: ReactNode
}

export function Callout({ kind = 'default', label, children }: CalloutProps) {
  const modifier = kind === 'default' ? '' : ` callout--${kind}`

  return (
    <div className={`callout${modifier} measure`}>
      <p className="eyebrow m-0">{label}</p>
      <div className="mt-1.5 text-[0.95rem] text-ink-soft">{children}</div>
    </div>
  )
}

export function PlateFigure({ plate }: { plate: PlateData }) {
  const [openHotspot, setOpenHotspot] = useState<string | null>(null)

  return (
    <Reveal>
      <figure id={plate.id} className="plate m-0 not-prose scroll-mt-28">
        <div className="plate__head">
          <span className="plate__no">{plate.plateNo}</span>
          <h3 className="plate__title">{plate.title}</h3>
        </div>
        <div className="plate__body">
          <img src={plate.src} alt={plate.alt} loading="lazy" decoding="async" />
          {plate.hotspots?.map((hotspot) => {
            const isOpen = openHotspot === hotspot.id

            return (
              <button
                key={hotspot.id}
                type="button"
                className="hotspot no-print"
                style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
                aria-expanded={isOpen}
                aria-label={`${hotspot.label}. ${hotspot.text}`}
                onMouseEnter={() => setOpenHotspot(hotspot.id)}
                onMouseLeave={() => setOpenHotspot((current) => (current === hotspot.id ? null : current))}
                onFocus={() => setOpenHotspot(hotspot.id)}
                onBlur={() => setOpenHotspot((current) => (current === hotspot.id ? null : current))}
                onClick={() => setOpenHotspot((current) => (current === hotspot.id ? null : hotspot.id))}
              >
                {isOpen ? (
                  <span className="hotspot__tip" role="tooltip">
                    <strong>{hotspot.label}</strong>
                    {hotspot.text}
                  </span>
                ) : null}
              </button>
            )
          })}
        </div>
        <div className="plate__caption">
          <p className="m-0">{plate.caption}</p>
          <a href={plate.src} target="_blank" rel="noreferrer" className="mt-2 inline-block font-ui text-[0.78rem] text-teal underline">
            Open original figure at full size
          </a>

          <div className="mt-4 pt-3 hair-rule">
            <p className="eyebrow m-0 mb-2">Annotation key — structure to function</p>
            <dl className="annotation-list m-0">
              {plate.annotations.map((annotation) => (
                <li key={annotation.label}>
                  <span className="anno-index">{annotation.n}</span>
                  <dt className="anno-label">{annotation.label}</dt>
                  <dd className="anno-text m-0">{annotation.text}</dd>
                </li>
              ))}
            </dl>
          </div>

          {plate.hotspots && plate.hotspots.length > 0 ? (
            <p className="mt-3 mb-0 font-ui text-[0.72rem] tracking-wide text-ink-faint">
              Circled markers on the image carry their own labels — hover, tap or keyboard-focus them.
            </p>
          ) : null}
        </div>
        <figcaption className="plate__source">{plate.source}</figcaption>
      </figure>
    </Reveal>
  )
}

export function FactRow({ items }: { items: { k: string; v: string }[] }) {
  return (
    <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2 xl:grid-cols-4 my-0">
      {items.map((item) => (
        <div key={item.k} className="border-t border-ink/15 pt-3">
          <dt className="font-ui text-[0.72rem] uppercase tracking-[0.14em] text-teal">{item.k}</dt>
          <dd className="mt-1 mb-0 text-[0.95rem] text-ink-soft">{item.v}</dd>
        </div>
      ))}
    </dl>
  )
}

export function Prose({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`measure text-[1.02rem] leading-[1.72] text-ink-soft ${className}`}>{children}</div>
}
