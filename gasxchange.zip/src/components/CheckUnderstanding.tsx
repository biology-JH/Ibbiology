import { useState } from 'react'
import { quizQuestions } from '../data/quiz'
import { levelClass } from '../data/syllabus'

const LETTERS = ['A', 'B', 'C', 'D', 'E']

export function CheckUnderstanding() {
  const [answers, setAnswers] = useState<Record<string, number>>({})

  const answered = Object.keys(answers).length
  const correct = quizQuestions.filter((question) => answers[question.id] === question.correctIndex).length

  return (
    <section id="check" className="scroll-mt-28 pt-7" aria-labelledby="check-heading">
      <header className="section-open grid gap-4 pt-7 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-10">
        <div>
          <span className="eyebrow">Checks for understanding</span>
          <h2 id="check-heading" className="mt-2 text-[1.85rem] sm:text-[2.15rem]">
            Check your understanding
          </h2>
        </div>
        <p className="measure text-[0.98rem] text-ink-soft lg:pt-9">
          Eight syllabus-tagged questions. Select an answer to see why.
        </p>
      </header>

      <p className="mt-6 font-mono text-[0.74rem] tracking-[0.1em] text-teal no-print" aria-live="polite">
        {answered} of {quizQuestions.length} answered · {correct} correct
      </p>

      <ol className="mt-6 grid list-none gap-6 p-0 xl:grid-cols-2">
        {quizQuestions.map((question, index) => {
          const selected = answers[question.id]
          const hasAnswered = selected !== undefined

          return (
            <li
              key={question.id}
              data-level={levelClass(question.level)}
              className="border-t border-ink/15 pt-4"
            >
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[0.7rem] text-ink-faint">Q{index + 1}</span>
                <span className="chip chip--sm">{question.code}</span>
                {question.level === 'HL ONLY' ? <span className="chip chip--hl chip--sm">HL ONLY</span> : null}
              </div>

              <p className="mt-2 mb-0 text-[1rem] text-ink">{question.question}</p>

              <div className="mt-3 flex flex-col gap-2">
                {question.options.map((option, optionIndex) => {
                  const isSelected = selected === optionIndex
                  const isCorrect = optionIndex === question.correctIndex
                  const state = !hasAnswered ? undefined : isSelected ? (isCorrect ? 'correct' : 'wrong') : undefined

                  return (
                    <button
                      key={option}
                      type="button"
                      className="quiz-option"
                      data-state={state}
                      aria-pressed={isSelected}
                      onClick={() => setAnswers((current) => ({ ...current, [question.id]: optionIndex }))}
                    >
                      <span className="quiz-mark" aria-hidden="true">
                        {hasAnswered && isCorrect ? '✓' : hasAnswered && isSelected ? '✗' : LETTERS[optionIndex]}
                      </span>
                      <span>{option}</span>
                    </button>
                  )
                })}
              </div>

              {hasAnswered ? (
                <div className="callout mt-3">
                  <p className="eyebrow m-0">{selected === question.correctIndex ? 'Correct' : 'Explanation'}</p>
                  <p className="mt-1.5 mb-0 text-[0.92rem] text-ink-soft">{question.explanation}</p>
                </div>
              ) : null}
            </li>
          )
        })}
      </ol>
    </section>
  )
}
