import { useState } from 'react'
import { glossary } from '../data/glossary'

export function Glossary() {
  const [query, setQuery] = useState('')

  const normalised = query.trim().toLowerCase()
  const entries = normalised
    ? glossary.filter(
        (entry) =>
          entry.term.toLowerCase().includes(normalised) || entry.definition.toLowerCase().includes(normalised),
      )
    : glossary

  return (
    <section id="glossary" className="scroll-mt-28 pt-7 pb-16" aria-labelledby="glossary-heading">
      <header className="section-open grid gap-4 pt-7 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-10">
        <div>
          <span className="eyebrow">Key terms</span>
          <h2 id="glossary-heading" className="mt-2 text-[1.85rem] sm:text-[2.15rem]">
            Glossary of the language examiners expect
          </h2>
        </div>
        <div className="lg:pt-9">
          <label className="eyebrow block" htmlFor="glossary-search">
            Filter terms
          </label>
          <input
            id="glossary-search"
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="e.g. allosteric, P50, transpiration"
            className="mt-2 w-full border border-ink/20 bg-white px-3 py-2 font-ui text-[0.85rem] text-ink placeholder:text-ink-faint/70"
          />
          <p className="mt-2 font-mono text-[0.7rem] text-ink-faint">
            {entries.length} of {glossary.length} terms
          </p>
        </div>
      </header>

      <dl className="mt-8 grid list-none gap-x-10 gap-y-0 p-0 md:grid-cols-2">
        {entries.map((entry) => (
          <div
            key={entry.term}
            data-level={entry.level === 'HL ONLY' ? 'hl' : 'sl'}
            className="border-t border-ink/15 py-4"
          >
            <dt className="flex flex-wrap items-baseline gap-2">
              <span className="font-display text-[1.05rem] font-semibold text-ink">{entry.term}</span>
              <span className="chip chip--sm">{entry.code}</span>
              {entry.level === 'HL ONLY' ? <span className="chip chip--hl chip--sm">HL</span> : null}
            </dt>
            <dd className="mt-1.5 mb-0 text-[0.92rem] text-ink-soft">{entry.definition}</dd>
          </div>
        ))}
      </dl>

      {entries.length === 0 ? (
        <p className="mt-8 text-ink-soft">
          No glossary term matches “{query}”. Try a shorter stem, such as “haem” or “stomat”.
        </p>
      ) : null}
    </section>
  )
}