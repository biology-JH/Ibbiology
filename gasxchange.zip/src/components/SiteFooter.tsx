import { syllabus } from '../data/syllabus'

export function SiteFooter() {
  const hlCount = syllabus.filter((statement) => statement.level === 'HL ONLY').length

  return (
    <footer className="mt-10 bg-teal-deep text-paper/85">
      <div className="mx-auto grid max-w-[1180px] gap-10 px-5 py-14 sm:px-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <div>
          <p className="wordmark m-0 text-[1.2rem] text-paper">GASTEMPERA</p>
          <p className="measure mt-4 text-[0.95rem] text-paper/80">
            IB Biology B3.1 gas exchange: {syllabus.length} syllabus points, including {hlCount} HL-only points.
          </p>

          <p className="eyebrow mt-8 text-amber-soft">Source note</p>
          <p className="mt-3 text-[0.9rem] text-paper/80">
            Original figures are embedded beside their matching lesson explanations.
          </p>
        </div>

        <div>
          <p className="eyebrow text-amber-soft">Jump to</p>
          <ul className="mt-3 grid list-none gap-2 p-0 text-[0.9rem]">
            {[
              { href: '#syllabus', label: 'Syllabus · B3.1.1–B3.1.13' },
              { href: '#haemoglobin', label: '§07 Haemoglobin · HL' },
              { href: '#bohr-shift', label: '§08 Bohr shift · HL' },
              { href: '#curves', label: '§09 O₂ curves · HL' },
              { href: '#synthesis', label: 'Linking questions' },
              { href: '#check', label: 'Quiz' },
              { href: '#glossary', label: 'Glossary' },
            ].map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-paper/80 no-underline hover:text-paper">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          <p className="eyebrow mt-8 text-amber-soft">Revision routine</p>
          <p className="mt-3 text-[0.9rem] text-paper/80">
            Study a figure, then recall the mechanism: haem groups, Bohr shift, sigmoid phases.
          </p>
        </div>
      </div>

      <div className="border-t border-paper/15">
        <div className="mx-auto flex max-w-[1180px] flex-wrap items-center justify-between gap-3 px-5 py-5 font-mono text-[0.7rem] tracking-wide text-paper/60 sm:px-8">
          <span>B3.1 gas exchange · SL &amp; HL</span>
          <span>Study aid · check against your syllabus</span>
        </div>
      </div>
    </footer>
  )
}
