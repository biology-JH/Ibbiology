import { Callout, PlateFigure, Prose, Section } from '../components/ui'
import { plateAlveolusEm, plateLungs, plateSav, plateSpirometry, plateVentilation } from '../data/figures'

export function PrinciplesSection() {
  return (
    <Section
      id="principles"
      number="01"
      title="Principles of gas exchange"
      level="SL & HL"
      codes={['B3.1.1', 'B3.1.2']}
      lede="Exchange surfaces solve the limits of diffusion as organisms grow."
    >
      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,0.75fr)]">
        <div>
          <Prose className="mb-4">
            <p className="mt-0">Gas exchange supplies O₂ and removes CO₂. As organisms grow, SA:V falls and diffusion distance increases.</p>
          </Prose>
          <div className="overflow-x-auto">
            <table className="data-table min-w-[42rem]">
              <caption>Why larger organisms need specialised gas exchange</caption>
              <thead>
                <tr><th scope="col">Scale</th><th scope="col">SA:V</th><th scope="col">Diffusion distance</th><th scope="col">Result</th></tr>
              </thead>
              <tbody>
                <tr><td>Small</td><td>High</td><td>Short</td><td>Body-surface diffusion may meet demand.</td></tr>
                <tr><td>Large</td><td>Low</td><td>Long to inner cells</td><td>Specialised surfaces and transport are needed.</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-[3px] border border-ink/15 bg-white/70 p-5">
          <p className="eyebrow m-0">Fick’s law</p>
          <p className="mt-2 mb-0 font-display text-[1.25rem] leading-snug text-ink">
            diffusion rate ∝ (area × gradient) ÷ barrier thickness
          </p>
          <p className="mt-3 mb-0 text-[0.92rem] text-ink-soft">More area or gradient, and a thinner barrier, speed diffusion.</p>
        </div>
      </div>

      <div className="mt-10 grid gap-10 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
        <div>
          <table className="data-table">
            <caption>The four universal adaptations of an exchange surface</caption>
            <thead>
              <tr>
                <th scope="col">Adaptation</th>
                <th scope="col">What it achieves</th>
                <th scope="col">Where to see it</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Large surface area</td>
                <td>Maximises the area available for diffusion at any instant.</td>
                <td>Roughly 70–100 m² of alveoli; the extensive air spaces of spongy mesophyll.</td>
              </tr>
              <tr>
                <td>Thin tissue layer</td>
                <td>Minimises the diffusion pathway, so the gradient is barely attenuated.</td>
                <td>Type I pneumocytes about 0.15 µm thick; thin mesophyll cell walls.</td>
              </tr>
              <tr>
                <td>Permeability</td>
                <td>Lets oxygen and carbon dioxide cross the membranes freely.</td>
                <td>Alveolar epithelium and capillary endothelium; the moist cell walls of the mesophyll.</td>
              </tr>
              <tr>
                <td>Moisture</td>
                <td>Gases must dissolve in an aqueous film before they can diffuse across a membrane.</td>
                <td>Humidified air in the respiratory tract; air spaces saturated with water vapour.</td>
              </tr>
            </tbody>
          </table>

          <Callout kind="exam" label="Exam move">
            <p className="m-0">
              As size increases, SA:V falls and diffusion distance grows; both limit surface exchange.
            </p>
          </Callout>
        </div>

        <PlateFigure plate={plateSav} />
      </div>
    </Section>
  )
}

export function GradientsSection() {
  return (
    <Section
      id="gradients"
      number="02"
      title="Maintaining concentration gradients"
      level="SL & HL"
      codes={['B3.1.3']}
      lede="Blood flow and ventilation maintain the gradients that drive diffusion."
    >
      <Prose>
        <p className="mt-0">
          Diffusion slows as concentrations equalise. Animals maintain gradients with dense blood vessels, continuous
          blood flow and ventilation.
        </p>
      </Prose>

      <div className="mt-8 overflow-x-auto">
        <table className="data-table min-w-[46rem]">
          <caption>Keeping the gradient steep — two exchange systems compared</caption>
          <thead>
            <tr>
              <th scope="col">Mechanism</th>
              <th scope="col">Mammalian lungs</th>
              <th scope="col">Fish gills</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Dense capillary bed</td>
              <td>
                Capillaries bring blood close to alveolar air.
              </td>
              <td>
                Gill lamellae bring blood close to water.
              </td>
            </tr>
            <tr>
              <td>Continuous blood flow</td>
              <td>
                Blood arrives deoxygenated and carries O₂ away.
              </td>
              <td>
                Blood carries absorbed O₂ to tissues.
              </td>
            </tr>
            <tr>
              <td>Ventilation medium</td>
              <td>
                Breathing replaces alveolar O₂ and removes CO₂.
              </td>
              <td>
                Water flows opposite to blood, maintaining counter-current exchange.
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Callout label="Counter-current exchange in gills">
          <p className="m-0">
            Water and blood flow in opposite directions, preserving an O₂ gradient along each lamella.
          </p>
        </Callout>
        <Callout label="Why lungs can use tidal flow">
          <p className="m-0">
            Air is O₂-rich, so lungs use tidal flow. Residual air remains between breaths; ventilation replenishes alveolar pO₂.
          </p>
        </Callout>
      </div>
    </Section>
  )
}

export function LungsSection() {
  return (
    <Section
      id="lungs"
      number="03"
      title="Mammalian respiratory system and lung volumes"
      level="SL & HL"
      codes={['B3.1.4', 'B3.1.6']}
      lede="Branched airways, thin alveoli and surfactant enable exchange; spirometry measures lung volumes."
    >
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
        <Prose>
          <p className="mt-0">
            The trachea branches into bronchi and bronchioles ending in millions of moist, ventilated alveoli, providing
            a large exchange area (about 70–100 m²).
          </p>
          <p>
            <span className="term">Type I pneumocytes</span> form the thin exchange surface.{' '}
            <span className="term">Type II pneumocytes</span> secrete surfactant, which lowers surface tension and prevents collapse.
          </p>
          <p>
            A fused basement membrane joins alveolar epithelium to capillary endothelium, shortening the diffusion path.
          </p>
        </Prose>

        <div className="rounded-[3px] border border-ink/15 bg-white/70 p-5">
          <p className="eyebrow m-0">Adaptations at a glance</p>
          <ul className="mt-3 mb-0 grid list-none gap-3 p-0 text-[0.94rem] text-ink-soft">
            <li>
              <strong className="text-ink">Branched bronchioles</strong> — spread ventilated air to every alveolus.
            </li>
            <li>
              <strong className="text-ink">High surface area</strong> — roughly 70–100 m² across approximately 300
              million alveoli.
            </li>
            <li>
              <strong className="text-ink">Surfactant</strong> — lowers surface tension and prevents alveolar collapse.
            </li>
            <li>
              <strong className="text-ink">Extensive capillary beds</strong> — each alveolus is wrapped in capillaries,
              maintaining the gradient.
            </li>
            <li>
              <strong className="text-ink">Thin, fused barrier</strong> — a single fused basement membrane between
              alveolar epithelium and endothelium.
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-10 grid gap-10">
        <PlateFigure plate={plateLungs} />
        <PlateFigure plate={plateAlveolusEm} />
      </div>

      <div className="mt-12">
        <div className="overflow-x-auto">
          <table className="data-table min-w-[34rem]">
            <caption>B3.1.6 — lung volumes measurable from a spirometer trace</caption>
            <thead>
              <tr>
                <th scope="col">Volume</th>
                <th scope="col">Definition</th>
                <th scope="col">Typical adult value</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Tidal volume, TV</td>
                <td>Air inhaled or exhaled in one normal resting breath.</td>
                <td>≈ 500 cm³</td>
              </tr>
              <tr>
                <td>Inspiratory reserve volume, IRV</td>
                <td>Maximum additional volume inhaled after a normal inspiration.</td>
                <td>≈ 3000 cm³</td>
              </tr>
              <tr>
                <td>Expiratory reserve volume, ERV</td>
                <td>Maximum additional volume exhaled after a normal expiration.</td>
                <td>≈ 1100 cm³</td>
              </tr>
              <tr>
                <td>Vital capacity, VC</td>
                <td>Maximum volume exhaled after a maximum inhalation.</td>
                <td>VC = TV + IRV + ERV ≈ 4600 cm³</td>
              </tr>
            </tbody>
          </table>

          <Callout kind="exam" label="Measurement skill">
            <p className="m-0">
              Read TV, IRV, ERV and VC. VC = TV + IRV + ERV; it excludes RV. Simple spirometry cannot measure RV directly.
            </p>
          </Callout>
        </div>

      </div>
      <div className="mt-8">
        <PlateFigure plate={plateSpirometry} />
      </div>
    </Section>
  )
}

export function VentilationSection() {
  return (
    <Section
      id="ventilation"
      number="04"
      title="Mechanism of ventilation"
      level="SL & HL"
      codes={['B3.1.5']}
      lede="Muscle action changes thoracic volume and pressure, moving air in or out."
    >
      <Prose>
        <p className="mt-0">
          Ventilation moves air down a pressure gradient. The diaphragm, intercostals, abdominal muscles and ribs change
          thoracic volume during inspiration and expiration.
        </p>
      </Prose>

      <div className="mt-8 overflow-x-auto">
        <table className="data-table min-w-[46rem]">
          <caption>Antagonistic muscle action during ventilation</caption>
          <thead>
            <tr>
              <th scope="col">Structure</th>
              <th scope="col">Inspiration</th>
              <th scope="col">Expiration (forced)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Diaphragm</td>
              <td>Contracts and flattens downwards, increasing thoracic volume vertically.</td>
              <td>Relaxes and is pushed upwards into a dome by abdominal pressure and elastic recoil.</td>
            </tr>
            <tr>
              <td>Intercostal muscles</td>
              <td>External intercostals contract, internal intercostals relax; the ribcage moves up and outwards.</td>
              <td>Internal intercostals contract, external intercostals relax; the ribcage is pulled down and inwards.</td>
            </tr>
            <tr>
              <td>Abdominal muscles</td>
              <td>Relax to accommodate the displacement of the viscera as the diaphragm descends.</td>
              <td>Contract, pressing the abdominal organs upward against the diaphragm.</td>
            </tr>
            <tr>
              <td>Ribs</td>
              <td>Act as levers pivoted at the vertebral column, increasing both the width and depth of the thorax.</td>
              <td>Swing down and inwards, reducing thoracic volume.</td>
            </tr>
            <tr>
              <td>Thoracic pressure</td>
              <td>Volume increases; internal pressure falls below atmospheric pressure; air rushes in.</td>
              <td>Volume decreases; internal pressure rises above atmospheric pressure; air is forced out.</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-10 grid gap-10 xl:grid-cols-[minmax(0,1fr)_minmax(0,22rem)]">
        <PlateFigure plate={plateVentilation} />
        <div className="grid content-start gap-6">
          <Callout label="Boyle’s law">
            <p className="m-0">
              At constant temperature, pressure varies inversely with volume: expanding the thorax draws air in; reducing it pushes air out.
            </p>
          </Callout>
          <Callout kind="exam" label="Exam move">
            <p className="m-0">
              Quiet expiration is mostly passive recoil. Forced expiration uses internal intercostals and abdominal muscles; ribs move down and in.
            </p>
          </Callout>
        </div>
      </div>
    </Section>
  )
}
