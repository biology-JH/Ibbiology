import { Callout, PlateFigure, Prose, Section } from '../components/ui'
import { plateBohrShift } from '../data/figures'

export function BohrShiftSection() {
  return (
    <Section
      id="bohr-shift"
      number="08"
      title="The Bohr shift"
      level="HL ONLY"
      codes={['B3.1.12']}
      lede="More CO₂ lowers haemoglobin affinity, increasing O₂ release in active tissues."
    >
      <Prose>
        <p className="mt-0">
          Respiring tissues release CO₂. In red blood cells, carbonic anhydrase catalyses:
        </p>
        <p className="font-mono text-[0.96rem] text-ink">CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻</p>
        <p>
          More CO₂ and H⁺ lower haemoglobin’s O₂ affinity. The curve shifts right: at the same pO₂, haemoglobin releases more O₂.
        </p>
      </Prose>

      <div className="mt-8">
        <PlateFigure plate={plateBohrShift} />
      </div>

      <Callout kind="hl" label="Benefit to active tissue">
        <p className="m-0">Hard-working cells make more CO₂ and receive more O₂; in the lungs, CO₂ loss reverses the shift and favours O₂ loading.</p>
      </Callout>
    </Section>
  )
}
