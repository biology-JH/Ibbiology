import { Callout, PlateFigure, Prose, Section } from '../components/ui'
import { plateEpidermis, plateLeafPlan, plateLeafSection } from '../data/figures'

export function LeafSection() {
  return (
    <Section
      id="leaf"
      number="05"
      title="Gas exchange in flowering plants"
      level="SL & HL"
      codes={['B3.1.7', 'B3.1.8', 'B3.1.9']}
      lede="Leaf air spaces connect moist mesophyll to the atmosphere through stomata."
    >
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,26rem)]">
        <Prose>
          <p className="mt-0">
            CO₂ diffuses in for photosynthesis; O₂ diffuses out. Both move between moist mesophyll and the atmosphere
            through air spaces and stomata.
          </p>
          <p>
            The cuticle limits water loss; the upper epidermis passes light; palisade cells photosynthesise; spongy
            mesophyll provides air spaces; xylem supplies water; phloem exports sugars; guard cells control stomata.
          </p>
        </Prose>

        <div className="rounded-[3px] border border-ink/15 bg-white/70 p-5">
          <p className="eyebrow m-0">B3.1.7 — leaf adaptations</p>
          <ul className="mt-3 mb-0 grid list-none gap-2.5 p-0 text-[0.94rem] text-ink-soft">
            <li>
              <strong className="text-ink">Waxy cuticle</strong> — hydrophobic barrier; reduces non-stomatal water loss.
            </li>
            <li>
              <strong className="text-ink">Upper epidermis</strong> — transparent single cell layer; transmits light.
            </li>
            <li>
              <strong className="text-ink">Palisade mesophyll</strong> — columnar, chloroplast-rich; light capture.
            </li>
            <li>
              <strong className="text-ink">Spongy mesophyll and air spaces</strong> — large internal surface for gas
              diffusion.
            </li>
            <li>
              <strong className="text-ink">Veins (vascular bundles)</strong> — xylem delivers water, phloem translocates
              photosynthates.
            </li>
            <li>
              <strong className="text-ink">Stomatal guard cells</strong> — regulate the aperture of each pore.
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-10 grid gap-10">
        <PlateFigure plate={plateLeafPlan} />
        <PlateFigure plate={plateLeafSection} />
      </div>

      <div className="mt-12 grid gap-10 xl:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
        <div className="overflow-x-auto">
          <table className="data-table min-w-[38rem]">
            <caption>B3.1.9 — environmental factors affecting the rate of transpiration</caption>
            <thead>
              <tr>
                <th scope="col">Factor</th>
                <th scope="col">Mechanism</th>
                <th scope="col">Effect on rate</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Light intensity</td>
                <td>Stomata open in light so that CO₂ can enter for photosynthesis.</td>
                <td>Increases, until all stomata are open and the rate plateaus.</td>
              </tr>
              <tr>
                <td>Temperature</td>
                <td>Raises the kinetic energy of water molecules and increases vaporisation within the leaf.</td>
                <td>Increases.</td>
              </tr>
              <tr>
                <td>Wind speed</td>
                <td>Removes the humid layer of air next to the leaf surface, maintaining a steep water-potential
                  gradient.</td>
                <td>Increases.</td>
              </tr>
              <tr>
                <td>Humidity</td>
                <td>High atmospheric humidity reduces the concentration gradient of water vapour between the air space
                  and the outside air.</td>
                <td>Decreases.</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="grid content-start gap-6">
          <Callout label="Transpiration is a trade-off">
            <p className="m-0">
              Open stomata admit CO₂ but lose water vapour. Closing them conserves water but limits photosynthesis.
            </p>
          </Callout>
          <Callout kind="exam" label="Plan diagram convention">
            <p className="m-0">
              Show tissue positions with clear outlines and labels; omit individual cell detail.
            </p>
          </Callout>
        </div>
      </div>
    </Section>
  )
}

export function StomataSection() {
  return (
    <Section
      id="stomata"
      number="06"
      title="Stomatal density and measurement skills"
      level="SL & HL"
      codes={['B3.1.10']}
      lede="Estimate stomatal density with calibrated, random, repeated counts."
    >
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
        <div>
          <Prose>
            <p className="mt-0">
              Density = stomata per unit leaf area. Use a micrograph or a leaf cast from the lower epidermis; casts avoid
              tearing and provide an even focus.
            </p>
          </Prose>

          <ol className="mt-6 grid list-none gap-4 p-0">
            {[
              'Prepare a lower-epidermis leaf cast or peel.',
              'Calibrate field diameter; calculate radius r.',
              'Calculate field area: πr² (mm²).',
              'Select fields randomly.',
              'Count stomata fully inside each field; repeat.',
              'Density = count ÷ area; report mean and variation.',
            ].map((step, index) => (
              <li key={step} className="grid grid-cols-[2rem_1fr] items-start gap-3 border-t border-ink/12 pt-3">
                <span className="anno-index">{index + 1}</span>
                <span className="text-[0.98rem] text-ink-soft">{step}</span>
              </li>
            ))}
          </ol>

          <Callout label="The formula">
            <p className="m-0 font-mono text-[0.92rem] leading-relaxed text-ink">
              stomatal density = number of stomata in the field of view ÷ area of the field of view (mm²)
              <br />
              area of field of view = πr²
            </p>
          </Callout>
        </div>

        <div className="grid content-start gap-6">
          <div className="overflow-x-auto rounded-[3px] border border-ink/15 bg-white/70 p-4">
            <p className="eyebrow m-0 mb-3">Worked example</p>
            <p className="m-0 text-[0.9rem] text-ink-soft">
              Field diameter 0.50 mm, so r = 0.25 mm and area = π(0.25)² = 0.196 mm².
            </p>
            <table className="data-table mt-3 !text-[0.82rem]">
              <thead>
                <tr>
                  <th scope="col">Field</th>
                  <th scope="col">Count</th>
                  <th scope="col">Density / mm⁻²</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>9</td>
                  <td>45.9</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>12</td>
                  <td>61.2</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>10</td>
                  <td>51.0</td>
                </tr>
                <tr>
                  <td>Mean</td>
                  <td>10.3</td>
                  <td>52.7</td>
                </tr>
              </tbody>
            </table>
            <p className="mt-3 mb-0 text-[0.88rem] text-ink-soft">
              Report the mean with spread: 52.7 ± 7.7 stomata mm⁻² (mean ± SD).
            </p>
          </div>
        </div>
      </div>

      <div className="mt-10 grid gap-10 xl:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
        <PlateFigure plate={plateEpidermis} />
        <div className="grid content-start gap-6">
          <Callout label="Nature of science — reliability of quantitative data">
            <p className="m-0">
              Reduce sampling bias and show variation:
            </p>
            <ul className="mt-2 mb-0 grid list-none gap-2 p-0">
              <li>Replicate counts across multiple randomly selected fields of view.</li>
              <li>Calculating the standard deviation and the standard error of the mean.</li>
              <li>Standardising leaf age, orientation and growth conditions.</li>
            </ul>
          </Callout>
          <Callout kind="exam" label="Exam move">
            <p className="m-0">
              Random sampling, replication and reported variation improve reliability. Compare leaf surfaces rather than averaging them together.
            </p>
          </Callout>
        </div>
      </div>
    </Section>
  )
}
