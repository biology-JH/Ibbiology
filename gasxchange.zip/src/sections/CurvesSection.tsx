import { Callout, PlateFigure, Prose, Section } from '../components/ui'
import { plateDissociation } from '../data/figures'

export function CurvesSection() {
  return (
    <Section
      id="curves"
      number="09"
      title="Oxygen dissociation curves"
      level="HL ONLY"
      codes={['B3.1.13']}
      lede="The curve represents haemoglobin saturation and O₂ affinity at different pO₂ values."
    >
      <Prose>
        <p className="mt-0">
          x-axis: pO₂ (kPa); y-axis: haemoglobin saturation (%). Higher saturation at the same pO₂ means higher affinity.
        </p>
        <p>
          P₅₀ is the pO₂ at 50% saturation. Lower P₅₀ means higher affinity and a left shift.
        </p>
      </Prose>

      <div className="mt-8">
        <PlateFigure plate={plateDissociation} />
      </div>

      <div className="mt-8 overflow-x-auto">
        <table className="data-table min-w-[38rem]">
          <caption>Why the oxygen dissociation curve is S-shaped</caption>
          <thead>
            <tr><th scope="col">Curve region</th><th scope="col">Binding event</th><th scope="col">Effect</th></tr>
          </thead>
          <tbody>
            <tr><td>Low pO₂ · shallow</td><td>First O₂ binds weakly.</td><td>Few haem groups are occupied.</td></tr>
            <tr><td>Middle · steep</td><td>Binding raises affinity at remaining haem groups.</td><td>Cooperative loading or unloading.</td></tr>
            <tr><td>High pO₂ · plateau</td><td>Most haem groups are occupied.</td><td>Further O₂ causes little saturation change.</td></tr>
          </tbody>
        </table>
      </div>

      <Callout kind="hl" label="Curve shifts">
        <p className="m-0">HbF: left shift, higher affinity. High CO₂ / low pH: right shift, lower affinity. A shift changes affinity, not O₂ capacity.</p>
      </Callout>
    </Section>
  )
}
