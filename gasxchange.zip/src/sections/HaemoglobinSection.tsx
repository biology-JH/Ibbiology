import { Callout, PlateFigure, Prose, Section } from '../components/ui'
import { plateCooperativeBinding } from '../data/figures'

export function HaemoglobinSection() {
  return (
    <Section
      id="haemoglobin"
      number="07"
      title="Adult and foetal haemoglobin"
      level="HL ONLY"
      codes={['B3.1.11']}
      lede="Four haem groups bind O₂ cooperatively; HbF has higher O₂ affinity than HbA."
    >
      <Prose>
        <p className="mt-0">
          Haemoglobin is a tetramer. Each globin subunit has a haem with Fe²⁺ that binds one O₂: up to four O₂ per molecule.
        </p>
        <p>
          The first O₂ changes haemoglobin’s shape and raises affinity at the remaining haem groups: <span className="term">cooperative binding</span>.
        </p>
        <p>
          CO₂ binds globin’s terminal −NH₂ groups, forming carbaminohaemoglobin. H⁺ binds elsewhere. Both lower O₂ affinity; neither occupies a haem group.
        </p>
      </Prose>

      <div className="mt-8">
        <PlateFigure plate={plateCooperativeBinding} />
      </div>

      <div className="mt-8 overflow-x-auto">
        <table className="data-table min-w-[34rem]">
          <caption>B3.1.11 · adult and foetal haemoglobin</caption>
          <thead>
            <tr><th scope="col">Feature</th><th scope="col">Adult HbA</th><th scope="col">Foetal HbF</th></tr>
          </thead>
          <tbody>
            <tr><td>Globin chains</td><td>α₂β₂</td><td>α₂γ₂</td></tr>
            <tr><td>O₂ capacity</td><td>Four O₂</td><td>Four O₂</td></tr>
            <tr><td>Affinity</td><td>Lower</td><td>Higher; left-shifted curve</td></tr>
            <tr><td>Role</td><td>Loads in lungs; unloads in tissue</td><td>Gains O₂ from maternal HbA</td></tr>
          </tbody>
        </table>
      </div>

      <Callout kind="hl" label="Key adaptation">
        <p className="m-0">HbF’s higher affinity favours O₂ transfer across the placenta.</p>
      </Callout>
    </Section>
  )
}
