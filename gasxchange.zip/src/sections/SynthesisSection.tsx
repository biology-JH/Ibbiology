import { Callout, Section } from '../components/ui'

export function SynthesisSection() {
  return (
    <Section
      id="synthesis"
      number="10"
      title="Linking questions"
      level="SL & HL"
      codes={['B3.1.1', 'B3.1.3', 'B3.1.4', 'B3.1.7', 'B3.1.9', 'B3.1.12']}
      lede="Connect exchange surfaces, transport and cellular metabolism."
    >
      <div className="overflow-x-auto">
        <table className="data-table min-w-[38rem]">
          <caption>Lung and leaf gas exchange</caption>
          <thead>
            <tr><th scope="col">Feature</th><th scope="col">Mammalian lung</th><th scope="col">Dicot leaf</th></tr>
          </thead>
          <tbody>
            <tr><td>Exchange surface</td><td>Thin alveolar wall beside capillaries</td><td>Moist mesophyll beside air spaces</td></tr>
            <tr><td>Gas movement</td><td>Ventilation and blood flow</td><td>Diffusion through stomata</td></tr>
            <tr><td>Water balance</td><td>Humid air; surfactant prevents collapse</td><td>Guard cells regulate water loss</td></tr>
          </tbody>
        </table>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <article className="section-open pt-5">
          <p className="eyebrow m-0">Linking question 1</p>
          <h3 className="mt-2 text-[1.25rem] text-ink">How do multicellular organisms supply all their cells?</h3>
          <ul className="mt-4 grid list-disc gap-2 pl-5 text-ink-soft">
            <li>Large, thin, moist exchange surfaces increase diffusion.</li>
            <li>Ventilation and blood flow maintain concentration gradients.</li>
            <li>Circulation, xylem and phloem transport materials over long distances.</li>
          </ul>
        </article>

        <article className="section-open pt-5">
          <p className="eyebrow m-0">Linking question 2</p>
          <h3 className="mt-2 text-[1.25rem] text-ink">How are gas exchange and cell metabolism related?</h3>
          <ul className="mt-4 grid list-disc gap-2 pl-5 text-ink-soft">
            <li>Aerobic respiration consumes O₂ to make ATP and produces CO₂.</li>
            <li>Gas exchange supplies O₂ and removes CO₂; active tissues make more CO₂.</li>
            <li>CO₂/H⁺ lower haemoglobin affinity, increasing O₂ release where demand is high.</li>
            <li>In plants, photosynthesis takes in CO₂ and releases O₂; respiration reverses this exchange.</li>
          </ul>
        </article>
      </div>

      <Callout kind="exam" label="Structure → function">
        <p className="m-0">Link each adaptation to its effect on surface area, barrier thickness, moisture or gradient.</p>
      </Callout>
    </Section>
  )
}
