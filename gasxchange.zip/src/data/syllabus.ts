export type Level = 'SL & HL' | 'HL ONLY'

export interface SyllabusStatement {
  /** Syllabus code, e.g. B3.1.11 */
  code: string
  level: Level
  /** Statement wording used on the syllabus coverage map. */
  text: string
  /** Anchor of the section that explains this statement. */
  sectionId: string
  /** Short label used in the navigation rail. */
  railLabel: string
}

export const syllabus: SyllabusStatement[] = [
  {
    code: 'B3.1.1',
    level: 'SL & HL',
    text: 'Gas exchange is vital in all organisms; as size increases, surface area-to-volume ratio decreases and diffusion distance from the centre to the exterior increases.',
    sectionId: 'principles',
    railLabel: 'Surface area to volume ratio',
  },
  {
    code: 'B3.1.2',
    level: 'SL & HL',
    text: 'Gas-exchange surfaces are adapted by permeability, a thin tissue layer, moisture and a large surface area.',
    sectionId: 'principles',
    railLabel: 'Properties of exchange surfaces',
  },
  {
    code: 'B3.1.3',
    level: 'SL & HL',
    text: 'Animals maintain concentration gradients at exchange surfaces using dense blood-vessel networks, continuous blood flow and ventilation with air or water.',
    sectionId: 'gradients',
    railLabel: 'Maintaining gradients',
  },
  {
    code: 'B3.1.4',
    level: 'SL & HL',
    text: 'Mammalian alveolar lungs are adapted by surfactant, branched bronchioles, extensive capillary beds and a high surface area.',
    sectionId: 'lungs',
    railLabel: 'Adaptations of mammalian lungs',
  },
  {
    code: 'B3.1.5',
    level: 'SL & HL',
    text: 'Ventilation involves the diaphragm, intercostal muscles, abdominal muscles and ribs.',
    sectionId: 'ventilation',
    railLabel: 'Mechanism of ventilation',
  },
  {
    code: 'B3.1.6',
    level: 'SL & HL',
    text: 'Lung-volume measurements determine tidal volume, vital capacity, inspiratory reserve volume and expiratory reserve volume.',
    sectionId: 'lungs',
    railLabel: 'Lung volumes',
  },
  {
    code: 'B3.1.7',
    level: 'SL & HL',
    text: 'Leaf adaptations include the waxy cuticle, epidermis, air spaces, spongy mesophyll, stomatal guard cells and veins.',
    sectionId: 'leaf',
    railLabel: 'Leaf adaptations',
  },
  {
    code: 'B3.1.8',
    level: 'SL & HL',
    text: 'A plan diagram can show the distribution of tissues in a transverse section of a dicotyledonous leaf.',
    sectionId: 'leaf',
    railLabel: 'Plan diagrams of a leaf',
  },
  {
    code: 'B3.1.9',
    level: 'SL & HL',
    text: 'Transpiration is a consequence of gas exchange in leaves; its rate is affected by environmental factors.',
    sectionId: 'leaf',
    railLabel: 'Transpiration trade-off',
  },
  {
    code: 'B3.1.10',
    level: 'SL & HL',
    text: 'Micrographs or leaf casts can be used to determine stomatal density; repeated measurements improve reliability.',
    sectionId: 'stomata',
    railLabel: 'Stomatal density and reliability',
  },
  {
    code: 'B3.1.11',
    level: 'HL ONLY',
    text: 'Adult and foetal haemoglobin are adapted for oxygen transport through cooperative oxygen binding and allosteric carbon-dioxide binding.',
    sectionId: 'haemoglobin',
    railLabel: 'Adult and foetal haemoglobin',
  },
  {
    code: 'B3.1.12',
    level: 'HL ONLY',
    text: 'The Bohr shift describes increased oxygen dissociation when carbon-dioxide concentration increases, benefiting actively respiring tissues.',
    sectionId: 'bohr-shift',
    railLabel: 'The Bohr shift',
  },
  {
    code: 'B3.1.13',
    level: 'HL ONLY',
    text: 'Oxygen dissociation curves represent haemoglobin affinity for oxygen at different oxygen concentrations; their S-shape is explained by cooperative binding.',
    sectionId: 'curves',
    railLabel: 'Oxygen dissociation curves',
  },
]

export const sectionOrder: { id: string; number: string; title: string; level: Level }[] = [
  { id: 'principles', number: '01', title: 'Principles of gas exchange', level: 'SL & HL' },
  { id: 'gradients', number: '02', title: 'Maintaining concentration gradients', level: 'SL & HL' },
  { id: 'lungs', number: '03', title: 'Mammalian respiratory system and lung volumes', level: 'SL & HL' },
  { id: 'ventilation', number: '04', title: 'Mechanism of ventilation', level: 'SL & HL' },
  { id: 'leaf', number: '05', title: 'Gas exchange in flowering plants', level: 'SL & HL' },
  { id: 'stomata', number: '06', title: 'Stomatal density and measurement skills', level: 'SL & HL' },
  { id: 'haemoglobin', number: '07', title: 'Haemoglobin and oxygen transport', level: 'HL ONLY' },
  { id: 'bohr-shift', number: '08', title: 'The Bohr shift and allosteric regulation', level: 'HL ONLY' },
  { id: 'curves', number: '09', title: 'Oxygen dissociation curves', level: 'HL ONLY' },
  { id: 'synthesis', number: '10', title: 'Comparative synthesis and linking questions', level: 'SL & HL' },
]

export const levelClass = (level: Level): 'hl' | 'sl' => (level === 'HL ONLY' ? 'hl' : 'sl')