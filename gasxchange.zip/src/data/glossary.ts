export interface GlossaryEntry {
  term: string
  code: string
  level: 'SL & HL' | 'HL ONLY'
  definition: string
}

export const glossary: GlossaryEntry[] = [
  { term: 'Surface area-to-volume ratio (SA:V)', code: 'B3.1.1', level: 'SL & HL', definition: 'Surface area ÷ volume. It falls as organisms grow, while diffusion distance increases.' },
  { term: 'Fick’s law', code: 'B3.1.2', level: 'SL & HL', definition: 'Diffusion rate ∝ surface area × concentration gradient ÷ barrier thickness.' },
  { term: 'Permeability', code: 'B3.1.2', level: 'SL & HL', definition: 'Allows gases to cross a membrane; moisture lets them dissolve before diffusing.' },
  { term: 'Partial pressure (pO₂, pCO₂)', code: 'B3.1.13', level: 'HL ONLY', definition: 'Pressure exerted by one gas in a mixture; measured in kPa and drives diffusion.' },
  { term: 'Affinity', code: 'B3.1.13', level: 'HL ONLY', definition: 'How readily haemoglobin binds O₂. Higher affinity gives higher saturation at a given pO₂.' },
  { term: 'P50', code: 'B3.1.13', level: 'HL ONLY', definition: 'pO₂ at 50% saturation. Lower P50 means higher O₂ affinity.' },
  { term: 'Cooperative binding', code: 'B3.1.11', level: 'HL ONLY', definition: 'O₂ binding raises the affinity of remaining haem groups, creating a sigmoid curve.' },
  { term: 'Allosteric binding', code: 'B3.1.11', level: 'HL ONLY', definition: 'Binding away from the haem changes protein shape; CO₂ and H⁺ lower O₂ affinity.' },
  { term: 'Carbaminohaemoglobin', code: 'B3.1.11', level: 'HL ONLY', definition: 'Haemoglobin formed when CO₂ binds a globin amino terminus (−NH₂).'},
  { term: 'Oxyhaemoglobin and deoxyhaemoglobin', code: 'B3.1.11', level: 'HL ONLY', definition: 'Oxyhaemoglobin carries O₂; deoxyhaemoglobin has empty haem groups and lower-affinity T state.' },
  { term: 'Foetal haemoglobin (HbF)', code: 'B3.1.11', level: 'HL ONLY', definition: 'α₂γ₂ haemoglobin; higher O₂ affinity and a left-shifted curve enable placental transfer.' },
  { term: 'Bohr shift', code: 'B3.1.12', level: 'HL ONLY', definition: 'Higher CO₂ and lower pH shift the curve right, promoting O₂ release in active tissue.' },
  { term: 'Pulmonary reversal', code: 'B3.1.12', level: 'HL ONLY', definition: 'CO₂ leaves blood in the lungs; pH rises, the curve shifts left and O₂ loads.' },
  { term: 'Sigmoid (S-shaped) curve', code: 'B3.1.13', level: 'HL ONLY', definition: 'Shallow at low pO₂, steep in the middle and flat near saturation due to cooperativity.' },
  { term: 'Type I pneumocyte', code: 'B3.1.4', level: 'SL & HL', definition: 'Flat alveolar epithelial cell; about 0.15 µm thick to shorten diffusion distance.' },
  { term: 'Type II pneumocyte and surfactant', code: 'B3.1.4', level: 'SL & HL', definition: 'Cell that secretes surfactant, lowering surface tension and preventing alveolar collapse.' },
  { term: 'Counter-current exchange', code: 'B3.1.3', level: 'SL & HL', definition: 'Opposite water and blood flow maintains an O₂ gradient along the gill lamella.' },
  { term: 'Tidal volume (TV)', code: 'B3.1.6', level: 'SL & HL', definition: 'Air inhaled or exhaled in a normal resting breath (about 500 cm³ in an adult).' },
  { term: 'Inspiratory and expiratory reserve volumes', code: 'B3.1.6', level: 'SL & HL', definition: 'IRV: extra air inhaled after normal inspiration. ERV: extra air exhaled after normal expiration.' },
  { term: 'Vital capacity (VC)', code: 'B3.1.6', level: 'SL & HL', definition: 'Maximum exhaled volume after maximum inhalation: VC = TV + IRV + ERV.' },
  { term: 'Transpiration', code: 'B3.1.9', level: 'SL & HL', definition: 'Water-vapour loss through stomata, coupled to CO₂ uptake.' },
  { term: 'Stomatal density', code: 'B3.1.10', level: 'SL & HL', definition: 'Stomata per unit leaf area; estimate from repeated random fields and report variation.' },
  { term: 'Plan diagram', code: 'B3.1.8', level: 'SL & HL', definition: 'A labelled drawing of tissue distribution using clear outlines, not cell detail.' },
]
