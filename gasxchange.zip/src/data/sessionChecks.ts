export interface SessionQuestion {
  id: string
  code: string
  prompt: string
  options: string[]
  correctIndex: number
  explanation: string
}

export const sessionChecks: Record<string, SessionQuestion[]> = {
  principles: [
    {
      id: 'principles-scale',
      code: 'B3.1.1',
      prompt: 'A same-shaped animal doubles in linear size. What happens to its SA:V ratio?',
      options: ['It doubles.', 'It halves.', 'It quadruples.', 'It stays constant.'],
      correctIndex: 1,
      explanation: 'Surface area ×4 but volume ×8, so SA:V halves.',
    },
    {
      id: 'principles-thickness',
      code: 'B3.1.2',
      prompt: 'At constant area and gradient, a diffusion barrier triples in thickness. The diffusion rate becomes…',
      options: ['Three times greater.', 'One-third as great.', 'One-ninth as great.', 'Unchanged.'],
      correctIndex: 1,
      explanation: 'By Fick’s law, rate is inversely proportional to barrier thickness.',
    },
  ],
  gradients: [
    {
      id: 'gradients-countercurrent',
      code: 'B3.1.3',
      prompt: 'Why does counter-current flow let a fish extract more O₂ than parallel flow?',
      options: [
        'Water and blood reach equal O₂ levels at the first lamella.',
        'Water stays higher in O₂ than blood along the lamella, preserving a gradient.',
        'Blood flows faster, so diffusion is no longer needed.',
        'O₂ diffuses from blood into water along the whole gill.',
      ],
      correctIndex: 1,
      explanation: 'Opposite flow keeps water at a higher O₂ partial pressure than blood at every point.',
    },
    {
      id: 'gradients-lung',
      code: 'B3.1.3',
      prompt: 'Which pair maintains the O₂ gradient between alveolar air and blood?',
      options: [
        'Ventilation replenishes alveolar O₂; blood flow carries O₂ away.',
        'Surfactant pumps O₂ into blood; diffusion moves CO₂ into alveoli.',
        'Blood flow replenishes alveolar air; ventilation carries O₂ away.',
        'Residual volume alone keeps the gradient steep.',
      ],
      correctIndex: 0,
      explanation: 'Ventilation refreshes alveolar air while blood flow removes absorbed O₂ and brings deoxygenated blood.',
    },
  ],
  lungs: [
    {
      id: 'lungs-residual',
      code: 'B3.1.6',
      prompt: 'A spirometer measures VC = 4.6 L. Which statement about residual volume (RV) is correct?',
      options: [
        'RV is included in VC and read directly from the trace.',
        'RV remains after maximal expiration; VC excludes it.',
        'RV equals TV + IRV.',
        'RV can be found by subtracting ERV from VC.',
      ],
      correctIndex: 1,
      explanation: 'VC = TV + IRV + ERV. RV remains in the lungs and is not measured by simple spirometry.',
    },
    {
      id: 'lungs-surfactant',
      code: 'B3.1.4',
      prompt: 'If type II pneumocytes produce too little surfactant, what is the direct consequence?',
      options: [
        'Surface tension rises, making alveoli more likely to collapse.',
        'The diffusion barrier thickens because type I cells divide.',
        'Alveoli become permanently overinflated.',
        'The capillary gradient reverses.',
      ],
      correctIndex: 0,
      explanation: 'Surfactant lowers surface tension and helps keep alveoli open; without it, collapse reduces exchange area.',
    },
  ],
  ventilation: [
    {
      id: 'ventilation-inspiration',
      code: 'B3.1.5',
      prompt: 'Which sequence correctly describes quiet inspiration?',
      options: [
        'Diaphragm relaxes → thoracic volume falls → pressure falls → air enters.',
        'Diaphragm contracts → thoracic volume rises → pressure falls → air enters.',
        'Diaphragm contracts → thoracic volume falls → pressure rises → air enters.',
        'Ribs move down and in → pressure falls → air enters.',
      ],
      correctIndex: 1,
      explanation: 'Diaphragm contraction and rib movement increase thoracic volume; pressure falls below atmospheric pressure.',
    },
    {
      id: 'ventilation-forced',
      code: 'B3.1.5',
      prompt: 'During forced expiration, which combination is expected?',
      options: [
        'External intercostals contract; ribs move up and out.',
        'Internal intercostals and abdominal muscles contract; thoracic volume falls.',
        'Diaphragm contracts; thoracic pressure falls below atmospheric pressure.',
        'Thoracic volume rises; alveolar pressure falls.',
      ],
      correctIndex: 1,
      explanation: 'Forced expiration uses internal intercostals and abdominal muscles to reduce thoracic volume and raise pressure.',
    },
  ],
  leaf: [
    {
      id: 'leaf-co2-route',
      code: 'B3.1.7',
      prompt: 'Which route best describes CO₂ entering a leaf for photosynthesis?',
      options: [
        'Stoma → xylem → upper epidermis → chloroplast.',
        'Stoma → air spaces → moist mesophyll wall → photosynthetic cells.',
        'Cuticle → phloem → guard cell → chloroplast.',
        'Palisade cell → spongy mesophyll → stoma.',
      ],
      correctIndex: 1,
      explanation: 'CO₂ diffuses through a stoma and air spaces, dissolves at moist mesophyll surfaces, then enters photosynthetic cells.',
    },
    {
      id: 'leaf-humidity',
      code: 'B3.1.9',
      prompt: 'Why does high atmospheric humidity usually lower transpiration?',
      options: [
        'It closes every stoma by increasing light intensity.',
        'It reduces the water-vapour gradient from leaf air spaces to the atmosphere.',
        'It makes the cuticle more permeable to water.',
        'It increases the temperature of the mesophyll.',
      ],
      correctIndex: 1,
      explanation: 'Moist outside air reduces the water-vapour concentration gradient, slowing diffusion out of the leaf.',
    },
  ],
  stomata: [
    {
      id: 'stomata-density',
      code: 'B3.1.10',
      prompt: 'A 0.40 mm-diameter field contains 16, 17 and 15 stomata in three random replicates. What is the mean density?',
      options: ['16 stomata mm⁻².', '≈ 64 stomata mm⁻².', '≈ 127 stomata mm⁻².', '≈ 382 stomata mm⁻².'],
      correctIndex: 2,
      explanation: 'Mean count = 16; area = π(0.20)² ≈ 0.126 mm²; density ≈ 16 ÷ 0.126 = 127 mm⁻².',
    },
    {
      id: 'stomata-sampling',
      code: 'B3.1.10',
      prompt: 'Which sampling design gives the most reliable estimate of leaf stomatal density?',
      options: [
        'Count one convenient field on one leaf and report the count.',
        'Count random fields on one leaf, calibrate area, repeat and report mean with variation.',
        'Choose the field with the most stomata and divide by leaf length.',
        'Count both surfaces together without recording which is which.',
      ],
      correctIndex: 1,
      explanation: 'Calibrated area, random replicate fields and reported variation reduce bias and show reliability.',
    },
  ],
  haemoglobin: [
    {
      id: 'haemoglobin-cooperation',
      code: 'B3.1.11',
      prompt: 'What causes cooperative O₂ binding in haemoglobin?',
      options: [
        'The first O₂ changes haemoglobin’s conformation, raising affinity at remaining haem groups.',
        'O₂ binds to globin and displaces Fe²⁺ from each haem.',
        'All four haem groups bind O₂ simultaneously.',
        'CO₂ occupies the haem groups before O₂ arrives.',
      ],
      correctIndex: 0,
      explanation: 'Binding promotes the higher-affinity R state, so subsequent O₂ molecules bind more readily.',
    },
    {
      id: 'haemoglobin-foetal',
      code: 'B3.1.11',
      prompt: 'At placental pO₂, why can HbF gain O₂ from maternal HbA?',
      options: [
        'HbF has more haem groups per molecule.',
        'HbF (α₂γ₂) has higher O₂ affinity than HbA (α₂β₂).',
        'HbF binds O₂ without iron.',
        'HbA has a higher affinity and unloads O₂ to HbF.',
      ],
      correctIndex: 1,
      explanation: 'The γ chains give HbF higher affinity (a left-shifted curve), favouring O₂ transfer from maternal HbA.',
    },
  ],
  'bohr-shift': [
    {
      id: 'bohr-mechanism',
      code: 'B3.1.12',
      prompt: 'At a fixed tissue pO₂, increased pCO₂ causes which sequence?',
      options: [
        'H⁺ falls → pH rises → curve shifts left → less O₂ released.',
        'H⁺ rises → pH falls → curve shifts right → more O₂ released.',
        'Haem groups increase → capacity rises → more O₂ binds.',
        'pH falls → affinity rises → curve shifts left.',
      ],
      correctIndex: 1,
      explanation: 'CO₂ hydration increases H⁺; lower pH reduces Hb affinity, so saturation falls and O₂ dissociates.',
    },
    {
      id: 'bohr-capacity',
      code: 'B3.1.12',
      prompt: 'What does the Bohr shift change directly?',
      options: [
        'Maximum O₂ capacity of each haemoglobin molecule.',
        'O₂ affinity and unloading at a given pO₂, not the number of haem groups.',
        'The number of red blood cells in the tissue.',
        'The diffusion coefficient of oxygen in plasma.',
      ],
      correctIndex: 1,
      explanation: 'The right shift lowers affinity and promotes unloading; it does not change haemoglobin’s four O₂-binding sites.',
    },
  ],
  curves: [
    {
      id: 'curves-sigmoid',
      code: 'B3.1.13',
      prompt: 'Why is the middle of the haemoglobin O₂ dissociation curve steep?',
      options: [
        'The first O₂ molecule binds most strongly.',
        'Binding increases affinity at the remaining haem groups, so saturation rises rapidly.',
        'All haem groups are already saturated.',
        'CO₂ displaces O₂ from haem in the lungs.',
      ],
      correctIndex: 1,
      explanation: 'Positive cooperativity makes further binding easier, producing the steep middle section.',
    },
    {
      id: 'curves-p50',
      code: 'B3.1.13',
      prompt: 'HbF has a lower P₅₀ than HbA. What does this show?',
      options: [
        'HbF has lower O₂ affinity and a right-shifted curve.',
        'HbF reaches 50% saturation at a lower pO₂, so its affinity is higher.',
        'HbF carries fewer O₂ molecules at full saturation.',
        'HbF has a lower maximum saturation.',
      ],
      correctIndex: 1,
      explanation: 'P₅₀ is the pO₂ at 50% saturation; a lower P₅₀ indicates higher affinity and a left shift.',
    },
  ],
  synthesis: [
    {
      id: 'synthesis-multicellular',
      code: 'B3.1.1–B3.1.3',
      prompt: 'Which change best solves the diffusion problem as a multicellular animal grows?',
      options: [
        'Rely on direct diffusion to every cell because volume rises faster than area.',
        'Add large, thin exchange surfaces and transport systems that maintain gradients.',
        'Thicken the exchange barrier to prevent water loss.',
        'Reduce blood flow so gases remain near the surface longer.',
      ],
      correctIndex: 1,
      explanation: 'Large area, short diffusion paths, ventilation and mass transport meet the needs of distant cells.',
    },
    {
      id: 'synthesis-metabolism',
      code: 'Linking question',
      prompt: 'In a brightly lit leaf, photosynthesis exceeds respiration. What is the expected net gas exchange?',
      options: [
        'O₂ enters and CO₂ leaves because photosynthesis consumes O₂.',
        'CO₂ enters and O₂ leaves, although respiration still occurs.',
        'Both gases leave because only respiration occurs in leaves.',
        'No net exchange occurs because photosynthesis and respiration are identical.',
      ],
      correctIndex: 1,
      explanation: 'Net photosynthesis consumes CO₂ and releases O₂; plant cells still respire at the same time.',
    },
  ],
}
