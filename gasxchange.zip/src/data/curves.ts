/**
 * A Hill-type model of oxygen binding used by the interactive figures.
 *
 * Saturation = 100 · pO₂ⁿ ÷ (pO₂ⁿ + P50ⁿ), where P50 is the partial pressure of
 * oxygen at which haemoglobin is 50% saturated and is therefore a direct measure
 * of affinity: a lower P50 means a higher affinity and a curve shifted to the left.
 *
 * The numbers below reproduce the shape and the relative positions of the three
 * curves in the study guide: adult haemoglobin, foetal haemoglobin and adult
 * haemoglobin in the presence of a raised carbon-dioxide concentration.
 */

export const HILL_COEFFICIENT = 2.8

export const P50 = {
  /** Adult haemoglobin at the partial pressure of carbon dioxide of alveolar air. */
  adult: 3.5,
  /** Foetal haemoglobin (γ chains instead of β chains) — higher affinity, curve left. */
  foetal: 2.6,
  /** Adult haemoglobin at a raised pCO₂ as found in actively respiring tissue — curve right. */
  adultHighCo2: 6.2,
} as const

/** Partial pressure of oxygen in alveolar air, in kPa. */
export const ALVEOLAR_PO2 = 13.3

/** Partial pressure of oxygen in resting tissue, in kPa. */
export const RESTING_TISSUE_PO2 = 4.0

/** Oxygen capacity of blood, in mL O₂ per 100 mL of blood when fully saturated. */
export const OXYGEN_CAPACITY_PER_100_ML = 20.1

export function saturation(pO2: number, p50: number, n: number = HILL_COEFFICIENT): number {
  if (pO2 <= 0) {
    return 0
  }

  const numerator = Math.pow(pO2, n)
  const denominator = numerator + Math.pow(p50, n)

  return (100 * numerator) / denominator
}

export interface CurveDefinition {
  id: 'adult' | 'foetal' | 'highCo2'
  label: string
  shortLabel: string
  p50: number
  colour: string
  description: string
}

export const curveDefinitions: CurveDefinition[] = [
  {
    id: 'adult',
    label: 'Adult haemoglobin (HbA)',
    shortLabel: 'HbA',
    p50: P50.adult,
    colour: '#0f4258',
    description: 'Loads in alveolar air; unloads where tissue pO₂ is low.',
  },
  {
    id: 'foetal',
    label: 'Foetal haemoglobin (HbF) — shifted left',
    shortLabel: 'HbF',
    p50: P50.foetal,
    colour: '#2f6b5f',
    description: 'γ chains give HbF higher affinity and a left-shifted curve for placental O₂ transfer.',
  },
  {
    id: 'highCo2',
    label: 'Adult haemoglobin with increased CO₂ — shifted right',
    shortLabel: '+ CO₂',
    p50: P50.adultHighCo2,
    colour: '#b3372b',
    description: 'CO₂/H⁺ lower affinity; the right shift increases O₂ unloading at the same pO₂.',
  },
]

/** Builds a sampled path for one curve across a partial-pressure range. */
export function sampleCurve(
  p50: number,
  xScale: (pO2: number) => number,
  yScale: (saturationPercent: number) => number,
  maxPO2 = 14,
  step = 0.1,
): string {
  const points: string[] = []

  for (let pO2 = 0; pO2 <= maxPO2 + 1e-9; pO2 += step) {
    const x = xScale(Number(pO2.toFixed(2)))
    const y = yScale(saturation(pO2, p50))
    points.push(`${points.length === 0 ? 'M' : 'L'}${x.toFixed(2)} ${y.toFixed(2)}`)
  }

  return points.join(' ')
}
