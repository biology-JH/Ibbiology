export interface Annotation {
  /** Number shown in the annotation legend. */
  n: number
  label: string
  text: string
}

export interface Hotspot {
  id: string
  /** Horizontal centre as a percentage of image width. */
  x: number
  /** Vertical centre as a percentage of image height. */
  y: number
  label: string
  text: string
}

export interface PlateData {
  id: string
  plateNo: string
  title: string
  src: string
  alt: string
  caption: string
  source: string
  annotations: Annotation[]
  hotspots?: Hotspot[]
}

const STUDY_GUIDE_SOURCE = 'Original figure from the attached B3.1 Gas Exchange study guide.'

export const plateSav: PlateData = {
  id: 'plate-sav',
  plateNo: 'Plate 01',
  title: 'Surface area to volume ratio',
  src: '/images/sav-cubes.png',
  alt: 'Two cubes of different size labelled surface area, volume and diffusion distance, both pointing to the need for specialised exchange surfaces and transport systems.',
  caption: 'As organisms grow, volume rises faster than surface area. SA:V falls and diffusion distance grows.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Small cube — high SA:V',
      text: 'High SA:V and short diffusion distances allow direct gas exchange.',
    },
    {
      n: 2,
      label: 'Large cube — low SA:V',
      text: 'Low SA:V means less exchange area per unit volume.',
    },
    {
      n: 3,
      label: 'Long diffusion distance',
      text: 'Long diffusion paths make diffusion too slow to meet demand.',
    },
    {
      n: 4,
      label: 'Specialised exchange surfaces and transport systems',
      text: 'Internal exchange surfaces and transport systems supply distant cells.',
    },
  ],
}

export const plateLungs: PlateData = {
  id: 'plate-lungs',
  plateNo: 'Plate 02',
  title: 'Lungs, airways and the alveolar capillary bed',
  src: '/images/lungs-anatomy.png',
  alt: 'Labelled anatomy of the human respiratory system showing trachea, bronchi, bronchioles, alveoli, ribs, diaphragm and an enlarged alveolus with its capillary network.',
  caption: 'Branching airways end in capillary-wrapped alveoli with a very thin gas-exchange barrier.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Trachea',
      text: 'Cartilage keeps it open; cilia and mucus trap particles.',
    },
    {
      n: 2,
      label: 'Bronchi',
      text: 'Cartilage-supported branches deliver air to each lung.',
    },
    {
      n: 3,
      label: 'Bronchioles',
      text: 'Smooth muscle adjusts airflow; fine branches end at alveoli.',
    },
    {
      n: 4,
      label: 'Alveoli',
      text: 'Numerous moist, thin sacs provide a large, permeable O₂/CO₂ exchange area.',
    },
    {
      n: 5,
      label: 'Capillary network',
      text: 'Continuous blood flow maintains the air–blood gradient.',
    },
    {
      n: 6,
      label: 'Diaphragm',
      text: 'Contraction flattens it and expands the thorax.',
    },
  ],
}

export const plateAlveolusEm: PlateData = {
  id: 'plate-alveolus-em',
  plateNo: 'Plate 03',
  title: 'Alveolar–capillary surface in section',
  src: '/images/alveolus-em.jpg',
  alt: 'Electron micrograph of the alveolar wall labelled with alveolar space, type I alveolar cell cytoplasmic extension, type II alveolar cell, endothelial cell and alveolar capillary.',
  caption: 'The air–blood barrier is formed by two thin cell layers, shortening the diffusion path.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Alveolar space',
      text: 'High alveolar pO₂ drives O₂ into the blood.',
    },
    {
      n: 2,
      label: 'Type I alveolar cell (cytoplasmic extension)',
      text: 'A flat, thin epithelial cell that shortens the diffusion path.',
    },
    {
      n: 3,
      label: 'Type II alveolar cell',
      text: 'Secretes surfactant, lowering surface tension and preventing collapse.',
    },
    {
      n: 4,
      label: 'Endothelial cell and nucleus',
      text: 'Endothelium and alveolar epithelium share a fused basement membrane.',
    },
    {
      n: 5,
      label: 'Alveolar capillary',
      text: 'Close capillary flow keeps blood near the alveolar wall.',
    },
  ],
}

export const plateVentilation: PlateData = {
  id: 'plate-ventilation',
  plateNo: 'Plate 04',
  title: 'Inspiration and expiration by antagonistic muscle action',
  src: '/images/ventilation.png',
  alt: 'Two labelled diagrams of the thorax showing air in with the diaphragm flattened and ribs up and out, and air out with the diaphragm domed and ribs down and in.',
  caption: 'Thoracic volume changes pressure: air enters on inspiration and leaves on expiration.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Inspiration — diaphragm flattens',
      text: 'Diaphragm flattens; ribs move up and out; thoracic volume rises and air enters.',
    },
    {
      n: 2,
      label: 'Expiration — diaphragm domes',
      text: 'Diaphragm domes; ribs move down and in; volume falls and air leaves.',
    },
    {
      n: 3,
      label: 'Forced expiration',
      text: 'Forced expiration uses internal intercostals and abdominal muscles.',
    },
    {
      n: 4,
      label: 'Rib movement',
      text: 'Ribs move up and out on inspiration, increasing thoracic volume.',
    },
  ],
}

export const plateLeafSection: PlateData = {
  id: 'plate-leaf',
  plateNo: 'Plate 05',
  title: 'Transverse section of a dicotyledonous leaf',
  src: '/images/leaf-cross-section.png',
  alt: 'Labelled transverse section of a dicotyledonous leaf showing waxy cuticle, upper epidermis, palisade mesophyll, vascular bundle with xylem and phloem, spongy mesophyll, air spaces, lower epidermis, guard cells and a stoma with carbon dioxide entering and water vapour leaving.',
  caption: 'Moist mesophyll surfaces exchange gases through air spaces and adjustable stomata.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Waxy cuticle',
      text: 'Waterproof layer that reduces water loss while transmitting light.',
    },
    {
      n: 2,
      label: 'Upper epidermis',
      text: 'Transparent layer that protects the tissues and passes light through.',
    },
    {
      n: 3,
      label: 'Palisade mesophyll',
      text: 'Chloroplast-rich cells that absorb most light for photosynthesis.',
    },
    {
      n: 4,
      label: 'Vascular bundle — xylem',
      text: 'Xylem supplies water and minerals to the leaf.',
    },
    {
      n: 5,
      label: 'Vascular bundle — phloem',
      text: 'Phloem transports sugars from the leaf to sinks.',
    },
    {
      n: 6,
      label: 'Spongy mesophyll and air spaces',
      text: 'Air spaces expose moist cell walls for CO₂ and O₂ diffusion.',
    },
    {
      n: 7,
      label: 'Lower epidermis, guard cells and stoma',
      text: 'Guard-cell turgor opens or closes the pore; CO₂ enters as water vapour exits.',
    },
  ],
}

export const plateEpidermis: PlateData = {
  id: 'plate-epidermis',
  plateNo: 'Plate 06',
  title: 'Leaf epidermis: stomata and guard cells',
  src: '/images/leaf-epidermis.jpg',
  alt: 'Light micrograph of leaf epidermis showing several stomata, each bounded by a pair of chloroplast-containing guard cells, surrounded by flat epidermal cells.',
  caption: 'Count stomata in known, randomly sampled areas to estimate density (number ÷ area).',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Guard cells',
      text: 'Turgid guard cells open the pore; loss of turgor closes it.',
    },
    {
      n: 2,
      label: 'Stoma (stomatal pore)',
      text: 'CO₂ diffuses in; water vapour diffuses out.',
    },
    {
      n: 3,
      label: 'Epidermal (pavement) cells',
      text: 'Flat protective cells surrounding the stomata.',
    },
    {
      n: 4,
      label: 'Field of view',
      text: 'Density = stomata counted ÷ field area; circular area = πr².',
    },
  ],
  hotspots: [
    {
      id: 'hs-guard-cells',
      x: 30,
      y: 19,
      label: 'Guard cells',
      text: 'Two crescent-shaped cells, each with chloroplasts, surrounding a single pore. Turgor changes their shape and so change the aperture.',
    },
    {
      id: 'hs-stoma',
      x: 51,
      y: 80,
      label: 'Stoma',
      text: 'The open pore of a stoma. Both CO₂ entry and water-vapour loss pass through this single controllable gap.',
    },
    {
      id: 'hs-epidermis',
      x: 63,
      y: 44,
      label: 'Epidermal cell',
      text: 'A large, flat pavement cell. The nucleus appears as a small raised disc; there are no chloroplasts in these cells.',
    },
    {
      id: 'hs-chloroplasts',
      x: 78,
      y: 23,
      label: 'Chloroplasts in guard cells',
      text: 'The green granules inside guard cells. Their photosynthesis supplies the ATP needed for the ion transport that opens the pore.',
    },
  ],
}

export const plateDissociation: PlateData = {
  id: 'plate-dissociation',
  plateNo: 'Plate 07',
  title: 'Oxygen dissociation curves for adult and foetal haemoglobin',
  src: '/images/hbdissociation.png',
  alt: 'Graph of percentage haemoglobin saturation against partial pressure of oxygen in kPa with three curves: foetal haemoglobin shifted left, adult haemoglobin central, and a right-shifted curve for increased carbon dioxide.',
  caption: 'The source graph shows the sigmoid, higher-affinity HbF left shift, and CO₂ right shift.',
  source: STUDY_GUIDE_SOURCE,
  annotations: [
    {
      n: 1,
      label: 'Axes',
      text: 'x-axis: pO₂ (kPa). y-axis: haemoglobin saturation (%).',
    },
    {
      n: 2,
      label: 'Cooperative binding — the S-shaped curve',
      text: 'Shallow at low pO₂; steep as binding raises affinity of remaining haem groups; flat near saturation.',
    },
    {
      n: 3,
      label: 'Adult haemoglobin (HbA)',
      text: 'HbA loads in the lungs and unloads where tissue pO₂ is low.',
    },
    {
      n: 4,
      label: 'Foetal haemoglobin (HbF) — shifted left',
      text: 'HbF has γ instead of β chains and higher O₂ affinity; its left-shifted curve enables placental transfer from HbA.',
    },
    {
      n: 5,
      label: 'Increased carbon dioxide — shifted right',
      text: 'CO₂/H⁺ lower affinity, shifting the curve right and increasing O₂ unloading at the same pO₂.',
    },
  ],
}

export const plateSpirometry: PlateData = {
  id: 'plate-spirometry',
  plateNo: 'Plate 08',
  title: 'Pulmonary volumes and spirometry trace',
  src: '/manus-storage/image2_5a2b858d.png',
  alt: 'Original labelled spirometry trace showing tidal volume, inspiratory and expiratory reserve volumes, residual volume, inspiratory capacity, vital capacity, functional residual capacity and total lung capacity.',
  caption: 'Use the trace to distinguish measured volumes from capacities that include residual volume.',
  source: 'Essential Biological Diagrams: Physiology & Anatomy.docx, Diagram 1 (user-supplied original).',
  annotations: [
    { n: 1, label: 'Tidal volume (TV)', text: 'Air inhaled or exhaled in a normal resting breath.' },
    { n: 2, label: 'IRV and ERV', text: 'Extra air inhaled after a normal inspiration, or exhaled after a normal expiration.' },
    { n: 3, label: 'Residual volume (RV)', text: 'Air left after maximal expiration; simple spirometry cannot measure it directly.' },
    { n: 4, label: 'Vital capacity (VC)', text: 'VC = TV + IRV + ERV; it excludes RV.' },
    { n: 5, label: 'Other capacities', text: 'Inspiratory capacity = TV + IRV; FRC = ERV + RV; total lung capacity = VC + RV.' },
  ],
}

export const plateLeafPlan: PlateData = {
  id: 'plate-leaf-plan',
  plateNo: 'Plate 09',
  title: 'Dicotyledonous leaf tissue plan',
  src: '/manus-storage/image4_db3e51a4.png',
  alt: 'Original labelled plan of a dicot leaf showing cuticle, upper epidermis, palisade mesophyll, spongy mesophyll, xylem, phloem, lower epidermis and guard cells.',
  caption: 'The tissue arrangement supports photosynthesis, gas diffusion and water transport.',
  source: 'Essential Biological Diagrams: Physiology & Anatomy.docx, Diagram 2 (user-supplied original).',
  annotations: [
    { n: 1, label: 'Cuticle and upper epidermis', text: 'Limit water loss and let light reach photosynthetic tissue.' },
    { n: 2, label: 'Palisade mesophyll', text: 'Chloroplast-rich cells absorb light for photosynthesis.' },
    { n: 3, label: 'Spongy mesophyll', text: 'Air spaces expose moist cell surfaces for gas diffusion.' },
    { n: 4, label: 'Xylem and phloem', text: 'Xylem supplies water; phloem transports sugars.' },
    { n: 5, label: 'Lower epidermis and guard cells', text: 'Guard cells regulate the stomatal pore.' },
  ],
}

export const plateCooperativeBinding: PlateData = {
  id: 'plate-cooperative-binding',
  plateNo: 'Plate 10',
  title: 'Cooperative binding in haemoglobin',
  src: '/manus-storage/image1_2b9763de.png',
  alt: 'Original diagram of adult haemoglobin with two alpha and two beta subunits, four Fe²⁺ haem groups and successive stages of oxygen binding.',
  caption: 'As O₂ binds, haemoglobin changes shape and the remaining haem groups gain affinity.',
  source: 'Essential Biological Diagrams: Physiology & Anatomy.docx, Diagram 3 (user-supplied original).',
  annotations: [
    { n: 1, label: 'Adult HbA chains', text: 'Two α and two β globin subunits form a tetramer.' },
    { n: 2, label: 'Haem and Fe²⁺', text: 'Each haem group binds one O₂ molecule.' },
    { n: 3, label: 'Sequential O₂ binding', text: 'Binding promotes a higher-affinity state at the remaining sites.' },
    { n: 4, label: 'Maximum occupancy', text: 'One haemoglobin molecule can carry up to four O₂ molecules.' },
  ],
}

export const plateBohrShift: PlateData = {
  id: 'plate-bohr-shift',
  plateNo: 'Plate 11',
  title: 'Erythrocyte carbonic anhydrase and the Bohr shift',
  src: '/manus-storage/image3_ef94dce5.png',
  alt: 'Original diagram showing carbon dioxide from respiring tissue entering an erythrocyte, carbonic anhydrase catalysing carbonic-acid formation, hydrogen ions and oxygen release, with a right-shifted oxygen dissociation curve.',
  caption: 'Respiring tissues raise CO₂ and H⁺; haemoglobin releases more O₂ at the same pO₂.',
  source: 'Essential Biological Diagrams: Physiology & Anatomy.docx, Diagram 4 (user-supplied original).',
  annotations: [
    { n: 1, label: 'CO₂ from respiring tissue', text: 'CO₂ diffuses into erythrocytes.' },
    { n: 2, label: 'Carbonic anhydrase', text: 'Catalyses CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻.' },
    { n: 3, label: 'H⁺ and haemoglobin', text: 'Higher H⁺ lowers haemoglobin’s O₂ affinity.' },
    { n: 4, label: 'Right shift', text: 'At the same pO₂, haemoglobin saturation falls and O₂ unloading rises.' },
  ],
}

export const allPlates: PlateData[] = [
  plateSav,
  plateLungs,
  plateAlveolusEm,
  plateVentilation,
  plateLeafSection,
  plateEpidermis,
  plateDissociation,
  plateSpirometry,
  plateLeafPlan,
  plateCooperativeBinding,
  plateBohrShift,
]
