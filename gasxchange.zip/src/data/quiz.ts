export interface QuizQuestion {
  id: string
  code: string
  level: 'SL & HL' | 'HL ONLY'
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 'q1', code: 'B3.1.1', level: 'SL & HL',
    question: 'Why does direct diffusion fail as an organism grows?',
    options: [
      'Its surface stops being permeable to oxygen.',
      'SA:V falls and diffusion distance increases.',
      'Its cells stop aerobic respiration.',
      'Diffusion works only in water.',
    ],
    correctIndex: 1,
    explanation: 'Growth lowers SA:V and increases diffusion distance; large organisms need exchange surfaces and transport systems.',
  },
  {
    id: 'q2', code: 'B3.1.11', level: 'HL ONLY',
    question: 'What does haemoglobin’s quaternary structure enable?',
    options: [
      'Four globin subunits, each with Fe²⁺ haem, bind up to four O₂.',
      'Four CO₂ molecules bind at the haem sites.',
      'Four amino acids surround one iron atom.',
      'Four separate functions occur in plasma.',
    ],
    correctIndex: 0,
    explanation: 'Four globin subunits carry four Fe²⁺ haem groups; each haem binds one O₂.',
  },
  {
    id: 'q3', code: 'B3.1.13', level: 'HL ONLY',
    question: 'Why is the oxygen dissociation curve S-shaped?',
    options: [
      'O₂ dissolves in plasma first.',
      'O₂ binding raises affinity at the remaining haem groups.',
      'CO₂ occupies haem at low pO₂.',
      'All four haem groups bind O₂ at once.',
    ],
    correctIndex: 1,
    explanation: 'The first O₂ changes haemoglobin’s shape, raising affinity at the remaining sites.',
  },
  {
    id: 'q4', code: 'B3.1.12', level: 'HL ONLY',
    question: 'As CO₂ rises at constant pO₂, what happens?',
    options: [
      'Affinity rises; curve shifts left.',
      'Affinity falls; curve shifts right and O₂ unloading increases.',
      'Affinity stays the same; curve becomes hyperbolic.',
      'Affinity falls, then rises above 8 kPa pO₂.',
    ],
    correctIndex: 1,
    explanation: 'CO₂/H⁺ lower affinity, shift the curve right and increase O₂ unloading in active tissue.',
  },
  {
    id: 'q5', code: 'B3.1.11', level: 'HL ONLY',
    question: 'How does CO₂ bind without competing for haem?',
    options: [
      'It binds globin −NH₂, forming carbaminohaemoglobin.',
      'It removes haem groups.',
      'It displaces Fe²⁺.',
      'It carries O₂ in plasma.',
    ],
    correctIndex: 0,
    explanation: 'CO₂ binds globin −NH₂; H⁺ binds elsewhere. Neither occupies haem.',
  },
  {
    id: 'q6', code: 'B3.1.11', level: 'HL ONLY',
    question: 'Why can HbF take O₂ from maternal blood?',
    options: [
      'HbF has β chains and lower saturation.',
      'HbF has lower affinity and releases O₂ to the mother.',
      'HbF has γ instead of β chains and higher O₂ affinity.',
      'HbF carries dissolved O₂, not haem-bound O₂.',
    ],
    correctIndex: 2,
    explanation: 'HbF (α₂γ₂) has higher affinity and a left-shifted curve, enabling placental O₂ transfer.',
  },
  {
    id: 'q7', code: 'B3.1.13', level: 'HL ONLY',
    question: 'What does P50 measure?',
    options: [
      'Maximum saturation at 14 kPa pO₂.',
      'pO₂ at 50% haemoglobin saturation.',
      'Area under the curve.',
      'Maximum curve slope.',
    ],
    correctIndex: 1,
    explanation: 'P50 is pO₂ at 50% saturation; lower P50 means higher affinity.',
  },
  {
    id: 'q8', code: 'B3.1.12', level: 'HL ONLY',
    question: 'What does CO₂ loss in alveolar capillaries do?',
    options: [
      'Shifts the curve further right.',
      'Lowers pH and raises affinity.',
      'Raises pH and affinity, restoring O₂ loading.',
      'Has no effect on O₂ loading.',
    ],
    correctIndex: 2,
    explanation: 'CO₂ loss raises pH and affinity, shifting the curve left so haemoglobin reloads O₂.',
  },
]
